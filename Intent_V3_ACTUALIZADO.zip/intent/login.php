<?php
session_start();
include('includes/connection_db.php'); // Conexión a la base de datos

if (isset($_POST['correo']) && isset($_POST['contraseña'])) {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Consultar si el correo corresponde a un administrador
    $sql_admin = "SELECT * FROM administradores WHERE correo_administradores = ?";
    $stmt_admin = $conn->prepare($sql_admin);
    $stmt_admin->bind_param('s', $correo);
    $stmt_admin->execute();
    $result_admin = $stmt_admin->get_result();

    if ($result_admin->num_rows > 0) {
        $row_admin = $result_admin->fetch_assoc();

        // Verificar la contraseña directamente
        if ($contraseña === $row_admin['contraseña_administradores']) {
            $_SESSION['admin_id'] = $row_admin['id_administradores'];
            $_SESSION['nombre_completo_admin'] = $row_admin['nombre_completo_administradores'];
            header('Location: index.php'); 
            exit();
        } else {
            echo "Contraseña incorrecta para el administrador.";
        }
    } else {
        // Consultar si el correo corresponde a un recepcionista
        $sql_recepcionista = "SELECT * FROM recepcionistas WHERE correo_recepcionistas = ?";
        $stmt_recepcionista = $conn->prepare($sql_recepcionista);
        $stmt_recepcionista->bind_param('s', $correo);
        $stmt_recepcionista->execute();
        $result_recepcionista = $stmt_recepcionista->get_result();

        if ($result_recepcionista->num_rows > 0) {
            $row_recepcionista = $result_recepcionista->fetch_assoc();

            // Verificar la contraseña directamente
            if ($contraseña === $row_recepcionista['contraseña_recepcionistas']) {
                $_SESSION['recepcionista_id'] = $row_recepcionista['id_recepcionistas'];
                $_SESSION['nombre_completo_recepcionista'] = $row_recepcionista['nombre_completo_recepcionistas'];
                header('Location: panel_recepcionista.php'); // Redirigir al panel del recepcionista
                exit();
            } else {
                echo "Contraseña incorrecta para el recepcionista.";
            }
        } else {
            // Consultar si el correo corresponde a un usuario
            $sql_usuario = "SELECT * FROM usuarios WHERE correo_usuarios = ?";
            $stmt_usuario = $conn->prepare($sql_usuario);
            $stmt_usuario->bind_param('s', $correo);
            $stmt_usuario->execute();
            $result_usuario = $stmt_usuario->get_result();

            if ($result_usuario->num_rows > 0) {
                $row_usuario = $result_usuario->fetch_assoc();

                // Verificar la contraseña directamente
                if ($contraseña === $row_usuario['contraseña_usuarios']) {
                    $_SESSION['usuario_id'] = $row_usuario['id_usuarios'];
                    $_SESSION['nombre_completo'] = $row_usuario['nombre_completo_usuarios'];
                    header('Location: index_login.php'); 
                    exit();
                } else {
                    echo "Contraseña incorrecta para el usuario.";
                }
            } else {
                echo "No se encontró el usuario con ese correo.";
            }
        }
    }
}

?>




<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>

    <!-- Vincula Font Awesome para los iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Estilos CSS incluidos directamente -->
    <style>
        /* Estilo para el logo de texto */
        .logo-container {
            text-align: center;
            margin-bottom: 30px; /* Espacio entre el logo y el formulario */
        }

        .logo {
            font-size: 36px;
            font-weight: bold;
            color: #ffffff;
            background-color: #007BFF; /* Fondo azul */
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            text-transform: uppercase;
            transition: background-color 0.3s ease;
        }

        .logo:hover {
            background-color: #0056b3; /* Color azul más oscuro al pasar el ratón */
        }

        /* Formulario de inicio de sesión */
        .formulario {
            max-width: 400px;
            margin: 0 auto;
            padding: 250px;
            background-color: #f4f4f4;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .input-container {
            position: relative;
            margin-bottom: 20px;
        }

        .input-container i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #333;
        }

        .input-container input {
            width: 100%;
            padding: 10px 40px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .registro-link {
            text-align: center;
            margin-top: 20px;
        }

        .registro-link a {
            color: #007BFF;
            text-decoration: none;
        }

        .registro-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Logo de texto con fondo azul, linkeado a index.php -->
    <div class="logo-container">
        <a href="index.php" class="logo">GYM</a>
    </div>

    <div class="formulario">
        <form method="POST" action="">
            <h2>Iniciar sesión</h2>

            <!-- Campo de correo -->
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="correo" placeholder="Correo electrónico" required>
            </div>

            <!-- Campo de contraseña -->
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="contraseña" placeholder="Contraseña" required>
            </div>

            <!-- Botón de iniciar sesión -->
            <button class="btn" type="submit">Iniciar sesión</button>

            <!-- Enlace para registrarse -->
            <p class="registro-link">¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>

            <!-- Mensaje de error -->
            <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
        </form>
    </div>

</body>
</html>
