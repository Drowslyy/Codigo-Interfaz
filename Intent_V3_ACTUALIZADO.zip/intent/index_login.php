<?php
session_start();

// Verificar si el usuario está logueado
$is_logged_in = isset($_SESSION['usuario_id']) || isset($_SESSION['admin_id']);

if ($is_logged_in) {
    // El usuario ha iniciado sesión, así que podemos mostrar opciones personalizadas
    $user_name = isset($_SESSION['nombre_completo']) ? $_SESSION['nombre_completo'] : $_SESSION['nombre_completo_admin'];
} else {
    // Si el usuario no ha iniciado sesión, redirigir a la página de login
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header class="header">

        <div class="menu container">
            <a href="index_login.php" class="logo">GYM</a>
            <input type="checkbox" id="menu" />
            <nav class="navbar">
                <ul>
                    <li><a href="index_login.php">Inicio</a></li>
                    <li><a href="acerca_de.php">Acerca de</a></li>
                    <li><a href="contacto.php">Contacto</a></li>

                    <!-- Opciones solo visibles para usuarios logueados -->
                    <li><a href="index_usuario.php">Mi perfil</a></li>
                    <li><a href="plan_membresia.php">Membresías</a></li>

                    <!-- Opción de Cerrar sesión -->
                    <li><a href="logout.php">Cerrar sesión</a></li>
                </ul>
            </nav>
        </div>

        <div class="header-content container">
            <div class="header-txt">
                <h1>Bienvenido a Central Gym, <?php echo htmlspecialchars($user_name); ?>!</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium earum nostrum, unde eveniet et ipsum, laudantium, fuga quae soluta 
                    minima veniam ullam. Cupiditate veniam nemo esse cumque sequi minima ipsam?
                </p>
                <a href="#" class="btn-1">Más Información</a>
            </div>
            <div class="header-img">
                <img src="ImageGimnasio/gym.jpg" alt="">
            </div>
        </div>
            
    </header>

    <section class="about container">

        <div class="about-txt">
            <h2>Acerca de Nosotros</h2>
            <p>
                
            </p>
            <br>
            <p>
            En Central Gym, nos apasiona ayudarte a alcanzar tus metas de bienestar físico y mental. Con un equipo altamente calificado y motivado, ofrecemos un ambiente de entrenamiento inclusivo, donde cada miembro puede desarrollar su potencial al máximo. Ya sea que estés buscando mejorar tu resistencia, tonificar tu cuerpo o encontrar equilibrio mental, estamos aquí para apoyarte en cada paso del camino. ¡Únete a nuestra comunidad y transforma tu vida con nosotros!
            </p>
        </div>
    </section>

    <main class="servicios">
        <h2>Servicios</h2>
        <div class="servicios-cont container">

            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador Personal</h3>
                <h7>Si buscas un enfoque más personalizado, nuestros entrenadores personales son expertos en diseñar rutinas adaptadas a tus objetivos y necesidades. Con su apoyo, lograrás una forma física óptima, mientras recibes la motivación y orientación necesaria para superar cada desafío. ¡Tu progreso es nuestra prioridad!</h7>

            </div>
            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador de Fuerza y Acondicionamiento</h3>
                <h7>¿Quieres mejorar tu fuerza y resistencia? Nuestros entrenadores especializados en fuerza y acondicionamiento te ayudarán a alcanzar un rendimiento físico excepcional. A través de programas diseñados para aumentar tu resistencia muscular y fuerza, serás capaz de desafiarte y conseguir resultados sorprendentes.</h7>

            </div>
            <div class="servicios-1">
                <i class="fa-solid fa-user"></i>
                <h3>Instructor de Yoga o Pilates</h3>
                <h7>El bienestar no solo es físico, también es mental. Si buscas mejorar tu flexibilidad, reducir el estrés o encontrar el equilibrio entre cuerpo y mente, nuestros instructores de yoga y pilates son la opción perfecta. Disfruta de clases diseñadas para mejorar tu postura, fortalecer tu cuerpo y encontrar paz interior.</h7>
            </div>
        </div>
    </main>

    <section class="formulario container">

        <form method="post" autocomplete="off">
            <h2>Contáctanos</h2>

            <div class="input-group">
                <div class="input-container">
                    <input type="text" name="nombre" placeholder="Nombre Completo" required>
                    <i class="fa-solid fa-user"></i>
                </div>
                <div class="input-container">
                    <input type="tel" name="phone" placeholder="9 XXXX XXXX" required>
                    <i class="fa-solid fa-phone"></i>
                </div>

                <div class="input-container">
                    <input type="text" name="Peso" placeholder="X Kg" required>
                    <i class="fa-solid fa-weight-hanging"></i>
                </div>
                <div class="input-container">
                    <input type="text" name="Altura" placeholder="X.XX Metros" required>
                    <i class="fa-solid fa-ruler-vertical"></i>
                </div>

                <div class="input-container">
                    <input type="email" name="email" placeholder="Correo Electrónico" required>
                    <i class="fa-solid fa-at"></i>
                </div>

                <div class="input-container">
                    <input type="text" name="nombre_entrenador" placeholder="Nombre del entrenador y servicio." required>
                    <i class="fa-solid fa-user"></i>
                </div>

                <div class="input-container">
                    <textarea type="message" name="Detalles" placeholder="Ingrese metas" required></textarea>
                </div>

                <div>
                    <input type="submit" name="send" class="btn" onClick="myFunction()">
                </div>

        </form>

    </section>



    <script>
        function myFunction(){
            windows.location.href = "http://localhost/gimnasio"
        }
    </script>

</body>
</html>
