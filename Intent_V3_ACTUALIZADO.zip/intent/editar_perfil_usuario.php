<?php
session_start();
include('includes/connection_db.php');

// Verificar si el cliente está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

// Obtener el ID del cliente desde la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener la información del cliente
$sql_cliente = "SELECT * FROM usuarios WHERE id_usuarios = ?";
$stmt_cliente = $conn->prepare($sql_cliente);
$stmt_cliente->bind_param('i', $usuario_id);
$stmt_cliente->execute();
$result_cliente = $stmt_cliente->get_result();

if ($result_cliente->num_rows > 0) {
    $row_cliente = $result_cliente->fetch_assoc();
    $nombre_completo = $row_cliente['nombre_completo_usuarios'];
    $correo = $row_cliente['correo_usuarios'];
} else {
    echo "No se encontró al cliente.";
    exit();
}

$mensaje = ""; // Variable para almacenar el mensaje de éxito o error

// Actualizar la información del perfil y la contraseña
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nueva_contraseña = $_POST['nueva_contraseña'];
    $confirmar_contraseña = $_POST['nueva_contraseña_confirmar'];

    // Validar que las contraseñas coincidan
    if ($nueva_contraseña != $confirmar_contraseña) {
        $mensaje = "Las contraseñas no coinciden.";
    } else {
        // Actualizar la contraseña en la base de datos (sin encriptación)
        $sql_actualizar = "UPDATE usuarios SET contraseña_usuarios = ? WHERE id_usuarios = ?";
        $stmt_actualizar = $conn->prepare($sql_actualizar);
        $stmt_actualizar->bind_param('si', $nueva_contraseña, $usuario_id);

        if ($stmt_actualizar->execute()) {
            $mensaje = "Contraseña actualizada con éxito.";
        } else {
            $mensaje = "Error al actualizar la contraseña.";
        }
    }

    // Actualizar la información del perfil
    $nuevo_nombre = $_POST['nombre_completo'];
    $nuevo_correo = $_POST['correo'];

    $sql_actualizar = "UPDATE usuarios SET nombre_completo_usuarios = ?, correo_usuarios = ? WHERE id_usuarios = ?";
    $stmt_actualizar = $conn->prepare($sql_actualizar);
    $stmt_actualizar->bind_param('ssi', $nuevo_nombre, $nuevo_correo, $usuario_id);

    if ($stmt_actualizar->execute()) {
        $mensaje = "Perfil actualizado con éxito.";
    } else {
        $mensaje = "Error al actualizar el perfil.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f4f9;
        color: #333;
        padding: 20px;
        line-height: 1.6;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    }

    .profile-header {
        text-align: center;
        margin-bottom: 30px;
    }

    .profile-header h1 {
        font-size: 36px;
        color: #0284C7;
        margin-bottom: 10px;
    }

    .profile-header p {
        font-size: 18px;
        color: #555;
    }

    .form-container {
        margin: 20px 0;
    }

    .form-container label {
        font-size: 16px;
        margin-bottom: 10px;
        display: block;
    }

    .form-container input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border-radius: 5px;
        border: 1px solid #ccc;
        font-size: 16px;
    }

    .btn {
        display: inline-block;
        background-color: #0284C7;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-size: 16px;
        margin-top: 20px;
        text-align: center;
        transition: background-color 0.3s ease;
    }

    .btn:hover {
        background-color: #0270A1;
    }

    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background-color: #4CAF50;
        color: white;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        display: none;
        z-index: 1000;
    }

    .notification.error {
        background-color: #f44336;
    }

    .back-btn {
        display: inline-block;
        background-color: #0284C7;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        text-decoration: none;
        font-size: 16px;
        margin-top: 20px;
        text-align: center;
        transition: background-color 0.3s ease;
    }

    .back-btn:hover {
        background-color: #0270A1;
    }
</style>
</head>
<body>
    <!-- Notificación emergente -->
    <?php if ($mensaje): ?>
        <div id="notification" class="notification <?php echo strpos($mensaje, 'Error') === false ? '' : 'error'; ?>">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <div class="container">
        <h1>Editar Perfil</h1>
        <div class="form-container">
            <form action="editar_perfil_usuario.php" method="post">
                <label for="nombre_completo">Nombre Completo:</label>
                <input type="text" name="nombre_completo" value="<?php echo $nombre_completo; ?>" required>
                
                <label for="correo">Correo Electrónico:</label>
                <input type="email" name="correo" value="<?php echo $correo; ?>" required>
                
                <label for="nueva_contraseña">Nueva Contraseña:</label>
                <input type="password" name="nueva_contraseña" required>
                
                <label for="nueva_contraseña_confirmar">Confirmar Nueva Contraseña:</label>
                <input type="password" name="nueva_contraseña_confirmar" required>
                
                <button type="submit" class="btn">Actualizar</button>
            </form>
        </div>

        <a href="index_usuario.php" class="back-btn">Volver al Perfil</a>
    </div>

    <script>
        // Mostrar la notificación si existe un mensaje
        <?php if ($mensaje): ?>
            document.getElementById('notification').style.display = 'block';
            setTimeout(function() {
                document.getElementById('notification').style.display = 'none';
            }, 5000); // Desaparece después de 5 segundos
        <?php endif; ?>
    </script>
</body>
</html>
