<?php
session_start();
include('includes/connection_db.php');

// Verificar si el cliente está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

// Obtener el ID del cliente desde la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener las membresías disponibles
$sql_membresias = "SELECT * FROM membresias";
$result_membresias = $conn->query($sql_membresias);

if ($result_membresias->num_rows > 0) {
    // Recuperar todas las filas de la consulta
    $membresias = $result_membresias->fetch_all(MYSQLI_ASSOC);
} else {
    $mensaje = "No se encontraron planes de membresía.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planes de Membresía</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
    body {
        font-family: 'Arial', sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f7f7f7;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 30px;
    }

    .header {
        text-align: center;
        margin-bottom: 30px;
    }

    .header h1 {
        font-size: 2.5em;
        color: #333;
    }

    .header p {
        font-size: 1.2em;
        color: #777;
    }

    .membresia-cards {
        display: flex;
        justify-content: space-between;
        gap: 20px;
        flex-wrap: wrap;
        justify-content: center; /* Alinea todas las tarjetas al centro */
    }

    .membresia-card {
        background-color: #ffffff;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        padding: 25px;
        width: 30%;
        transition: all 0.3s ease;
        text-align: center;
        margin-bottom: 30px;
    }

    .membresia-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
    }

    .membresia-card h2 {
        font-size: 1.8em;
        color: #333;
        margin-bottom: 15px;
    }

    .membresia-card p {
        font-size: 1.1em;
        color: #555;
        margin-bottom: 10px;
    }

    .precio {
        font-size: 1.6em;
        color: #00bfae;
        font-weight: bold;
        margin-bottom: 15px;
    }

    .beneficios {
        font-size: 1em;
        color: #777;
        margin-top: 10px;
        text-align: left;
        padding-left: 20px;
    }

    .beneficios li {
        margin: 5px 0;
        list-style-type: none;
    }

    .beneficios i {
        color: #00bfae;
        margin-right: 10px;
    }

    .btn {
        display: inline-block;
        background-color: #00bfae;
        color: white;
        padding: 12px 30px;
        border-radius: 30px;
        text-decoration: none;
        font-weight: bold;
        margin-top: 20px;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .btn:hover {
        background-color: #009f8b;
        transform: translateY(-5px);
    }

    /* Centrar la tarjeta de la membresía mensual */
    .membresia-card.mensual {
        margin: 5 auto; /* Centra la tarjeta de la membresía mensual */
    }

    @media screen and (max-width: 768px) {
        .membresia-card {
            width: 45%;
        }
    }

    @media screen and (max-width: 480px) {
        .membresia-card {
            width: 100%;
        }
    }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Planes de Membresía</h1>
            <p>Elige el plan de membresía que más se ajuste a tus necesidades y comienza a disfrutar de los beneficios.</p>
        </div>

        <div class="membresia-cards">
            <?php if (!empty($membresias)): ?>
                <?php foreach ($membresias as $membresia): ?>
                    <div class="membresia-card <?php echo ($membresia['tipo_membresias'] == 'Mensual') ? 'mensual' : ''; ?>">
                        <h2><?php echo htmlspecialchars($membresia['tipo_membresias']); ?></h2>
                        <p>Duración: <?php echo $membresia['duracion_membresias']; ?> días</p>
                        <p class="precio">$<?php echo number_format($membresia['precio_membresias'], 2); ?> / mes</p>
                        <div class="beneficios">
                            <h3>Beneficios:</h3>
                            <ul>
                                <?php 
                                    // Separar los beneficios por comas y mostrar en lista
                                    $beneficios = explode(',', $membresia['beneficios_membresias']);
                                    foreach ($beneficios as $beneficio) {
                                        echo "<li><i class='fas fa-check-circle'></i>" . htmlspecialchars(trim($beneficio)) . "</li>";
                                    }
                                ?>
                            </ul>
                        </div>
                        <a href="suscribirse.php?id=<?php echo $membresia['id_membresias']; ?>" class="btn">Suscribirse</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No hay planes de membresía disponibles en este momento.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
