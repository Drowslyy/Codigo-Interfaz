<?php
session_start();
include('includes/connection_db.php');

// Verificar si el cliente está logueado
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir a la página de login si no hay sesión activa
    header('Location: login.php');
    exit();
}

// Obtener el ID del cliente desde la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la base de datos para obtener la información del cliente
$sql_cliente = "SELECT * FROM usuarios WHERE id_usuarios = ?";
$stmt_cliente = $conn->prepare($sql_cliente);
$stmt_cliente->bind_param('i', $usuario_id);
$stmt_cliente->execute();
$result_cliente = $stmt_cliente->get_result();

if ($result_cliente->num_rows > 0) {
    // Obtener la información del cliente
    $row_cliente = $result_cliente->fetch_assoc();
    $nombre_completo = $row_cliente['nombre_completo_usuarios'];
    $correo = $row_cliente['correo_usuarios'];
} else {
    echo "No se encontró al cliente.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Cliente</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-header h1 {
            font-size: 36px;
            color: #0284C7;
            margin-bottom: 10px;
        }

        .profile-header p {
            font-size: 18px;
            color: #555;
        }

        .profile-info, .historial-pagos, .reservas {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .profile-info h3, .historial-pagos h3, .reservas h3 {
            font-size: 24px;
            color: #0284C7;
            margin-bottom: 15px;
        }

        .profile-info p, .historial-pagos p, .reservas p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .btn {
            display: inline-block;
            background-color: #0284C7;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0270A1;
        }

        .acciones {
            text-align: center;
            margin-bottom: 30px;
        }

    </style>
</head>
<body>

    <div class="container">
        <!-- Opciones adicionales -->
        <div class="acciones">
            <a href="editar_perfil_usuario.php" class="btn">Editar perfil</a>
            <a href="plan_membresia.php" class="btn">Ver plan de membresía</a>
            <a href="historial_clases.php" class="btn">Historial de clases</a>
            <a href="index_login.php" class="btn">Volver</a>
            <a href="logout.php" class="btn">Cerrar sesión</a>
        </div>

        <!-- Encabezado de perfil -->
        <div class="profile-header">
            <h1>Bienvenido, <?php echo $nombre_completo; ?>!</h1>
            <p>Información de tu cuenta</p>
        </div>

        <!-- Información de cuenta -->
        <div class="profile-info">
            <h3>Información de tu cuenta</h3>
            <p><strong>Correo electrónico:</strong> <?php echo $correo; ?></p>
            <p><strong>Nombre completo:</strong> <?php echo $nombre_completo; ?></p>
        </div>

        <!-- Historial de pagos -->
        <div class="historial-pagos">
            <h3>Historial de Pagos</h3>
            <?php
            // Consultar el historial de pagos del cliente
            $sql_pagos = "SELECT * FROM pagos WHERE cliente_id_pagos = ?";
            $stmt_pagos = $conn->prepare($sql_pagos);
            $stmt_pagos->bind_param('i', $usuario_id);
            $stmt_pagos->execute();
            $result_pagos = $stmt_pagos->get_result();

            if ($result_pagos->num_rows > 0) {
                while ($row_pago = $result_pagos->fetch_assoc()) {
                    echo "<p>Pago de " . $row_pago['monto_pagos'] . " realizado el " . $row_pago['fecha_pago_pagos'] . "</p>";
                }
            } else {
                echo "<p>No has realizado pagos todaavía.</p>";
            }
            ?>
        </div>

        <!-- Reservas -->
        <div class="reservas">
            <h3>Reservas</h3>
            <?php
            // Consultar las reservas del cliente
            $sql_reservas = "SELECT * FROM reservas WHERE cliente_id_reservas = ?";
            $stmt_reservas = $conn->prepare($sql_reservas);
            $stmt_reservas->bind_param('i', $usuario_id);
            $stmt_reservas->execute();
            $result_reservas = $stmt_reservas->get_result();

            if ($result_reservas->num_rows > 0) {
                while ($row_reserva = $result_reservas->fetch_assoc()) {
                    echo "<p>Reserva para la clase de " . $row_reserva['fecha_reserva_reservas'] . " de " . $row_reserva['hora_inicio_reservas'] . " a " . $row_reserva['hora_fin_reservas'] . "</p>";
                }
            } else {
                echo "<p>No tienes reservas actuales.</p>";
            }
            ?>
        </div>

    </div>

</body>
</html>
