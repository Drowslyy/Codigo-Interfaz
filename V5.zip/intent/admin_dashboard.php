<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym</title>
    <link rel="stylesheet" href="style/style_admindashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Estilos del cuadro de bienvenida */
        .bienvenida {
            padding: 30px;
            background-color: #fafafa;
            border: 1px solid #ccc;
            max-width: 400px;
            text-align: center;
            font-size: 18px;
            font-family: Arial, sans-serif;
            color: #333;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        

    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                var mensaje = document.getElementById("mensajeBienvenida");
                if (mensaje) {
                    mensaje.style.display = "none";
                }
            }, 3000); // 3000 ms = 3 segundos
        });
    </script>
</head>
<body>

    <div class="cuadros-container">
        <a href="#" class="cuadro">
            <h3>Ver Inicio</h3>
            <p>Ver pagina inicial.</p>
        </a>
        <a href="#" class="cuadro">
            <h3>Ver Nosotros</h3>
            <p>Ver pagina relacionada a nuestro gimnasio.</p>
        </a>
        <a href="#" class="cuadro">
            <h3>Ver Servicios</h3>
            <p>Explorar servicio del gimnasio.</p>
        </a>
        <a href="recepcion-herr.php" class="cuadro">
            <h3>Ver Recepción</h3>
            <p>Accede a la recepción</p>
        </a>
        <a href="clientes-herr.php" class="cuadro">
            <h3>Ver Clientes</h3>
            <p>Gestión de clientes</p>
        </a>
        <a href="pagos-herr.php" class="cuadro">
            <h3>Ver Pagos</h3>
            <p>Consulta pagos realizados</p>
        </a>
        <a href="#" class="cuadro">
            <h3>Ver Actividades</h3>
            <p>Realizar actividade, programar y reprogramar.</p>
        </a>
    </div>

    <div id="mensajeBienvenida" class="bienvenida">
        <?php
        echo "Bienvenido " . $_SESSION['nombre_completo_admin'] . "\n(Administrador)";
        ?>
    </div>

    <a href="logout.php" class="btn-cerrar-sesion">Cerrar sesión</a>

</body>
</html>
