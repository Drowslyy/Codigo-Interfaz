<?php
function conectarBaseDatos() {
    $conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }
    return $conexion;
}

function obtenerRecepcionista($id_recepcionista) {
    $conexion = conectarBaseDatos();
    $sql = "SELECT * FROM recepcionistas WHERE id_recepcionistas = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_recepcionista);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $recepcionista = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);
    mysqli_close($conexion);
    return $recepcionista;
}

function obtenerPagos($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT p.id_pagos, u.nombre_completo_usuarios AS nombre_cliente, p.monto_pagos, p.fecha_pago_pagos
            FROM pagos p
            LEFT JOIN clientes c ON p.cliente_id_pagos = c.id_clientes
            LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";
    if ($filtro) {
        $sql .= " WHERE u.nombre_completo_usuarios LIKE '%$filtro%' OR p.fecha_pago_pagos LIKE '%$filtro%'";
    }
    $sql .= " ORDER BY p.fecha_pago_pagos DESC";
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}

function obtenerReservas($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT r.id_reservas, u.nombre_completo_usuarios AS nombre_cliente, r.fecha_reserva_reservas
            FROM reservas r
            LEFT JOIN clientes c ON r.cliente_id_reservas = c.id_clientes
            LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";
    if ($filtro) {
        $sql .= " WHERE u.nombre_completo_usuarios LIKE '%$filtro%' OR r.fecha_reserva_reservas LIKE '%$filtro%'";
    }
    $sql .= " ORDER BY r.fecha_reserva_reservas DESC";
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}

function obtenerUsuarios($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT * FROM usuarios";
    if ($filtro) {
        $sql .= " WHERE nombre_completo_usuarios LIKE '%$filtro%' OR correo_usuarios LIKE '%$filtro%'";
    }
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}
?>
