<?php 
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Procesar la edición de un recepcionista
if (isset($_POST['editar'])) {
    $id_recepcionista = $_POST['id_recepcionista'];
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];

    // Actualizar en la base de datos
    $sql = "UPDATE recepcionistas SET nombre_completo_recepcionistas = ?, correo_recepcionistas = ?, telefono_recepcionistas = ? WHERE id_recepcionistas = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sssi", $nombre_completo, $correo, $telefono, $id_recepcionista);

    if (mysqli_stmt_execute($stmt)) {
        echo "<p>Recepcionista actualizado correctamente.</p>";
    } else {
        echo "<p>Error al actualizar los datos: " . mysqli_error($conexion) . "</p>";
    }
    mysqli_stmt_close($stmt);
}

// Consulta para obtener todos los recepcionistas
$sql = "SELECT * FROM recepcionistas";
$resultado = mysqli_query($conexion, $sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Error en la consulta SQL: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recepción - Gestión de Personal</title>
    <link rel="stylesheet" href="style/style_recepcionadmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>


    <main>
        <section class="container">
            <h1>Gestión de Personal de Recepción</h1>

            <!-- Formulario de edición, si se selecciona un recepcionista -->
            <?php if (isset($_GET['editar_id'])) {
                $id_recepcionista = $_GET['editar_id'];
                $sql = "SELECT * FROM recepcionistas WHERE id_recepcionistas = ?";
                $stmt = mysqli_prepare($conexion, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id_recepcionista);
                mysqli_stmt_execute($stmt);
                $resultado = mysqli_stmt_get_result($stmt);
                $recepcionista = mysqli_fetch_assoc($resultado);
                mysqli_stmt_close($stmt);
            ?>
            
                <h2>Editar Recepcionista</h2>
                <form action="recepcion-herr.php" method="POST">
                    <input type="hidden" name="id_recepcionista" value="<?php echo $recepcionista['id_recepcionistas']; ?>">

                    <label for="foto_perfil">Foto de Perfil:</label>
                    <input type="file" id="foto_perfil" name="foto_perfil" accept="image/png, image/jpeg"><br><br>


                    <label for="estado">Estado:</label>
                    <input type="text" id="estado" name="nombre_completo" value="<?php echo htmlspecialchars($recepcionista['estado_recepcionistas']); ?>" required><br><br>

                    <label for="nombre_completo">Nombre Completo:</label>
                    <input type="text" id="nombre_completo" name="nombre_completo" value="<?php echo htmlspecialchars($recepcionista['nombre_completo_recepcionistas']); ?>" required><br><br>

                    <label for="Dirección">Dirección:</label>
                    <input type="text" id="Dirección" name="Dirección" value="<?php echo htmlspecialchars($recepcionista['direccion_recepcionistas']); ?>" required><br><br>


                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($recepcionista['correo_recepcionistas']); ?>" required><br><br>

                    <label for="telefono">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($recepcionista['telefono_recepcionistas']); ?>" required><br><br>

                    <button type="submit" name="editar" class="btn">Guardar Cambios</button>
                </form>
            <?php } ?>

            <div class="button-group">
                <a href="admin_dashboard.php" class="btn btn-regresar">Regresar</a>
                <a href="añadir_recepcionista.php" class="btn">Añadir Recepción</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Foto Perfil</th>
                        <th>ID</th>
                        <th>Estado</th>
                        <th>Nombre Completo</th>
                        <th>Direccion</th>
                        <th>Email</th>
                        <th>Teléfono</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>

                <?php
            // Consulta para obtener los recepcionistas
        $conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
        $query = "SELECT * FROM recepcionistas";
        $resultado = mysqli_query($conexion, $query);

        ?>
                    <?php  while ($row = $resultado->fetch_assoc()) { ?>
                        <tr>
                            
                            <td><img src='uploads/<?php echo htmlspecialchars($row['foto_perfil_recepcionistas']); ?>' alt='Foto de perfil' class='foto-recepcionista'></td>

                            <td><?php echo htmlspecialchars($row['id_recepcionistas']); ?></td>
                            <td><?php echo htmlspecialchars($row['estado_recepcionistas']); ?></td>

                            <td><?php echo htmlspecialchars($row['nombre_completo_recepcionistas']); ?></td>
                            <td><?php echo htmlspecialchars($row['direccion_recepcionistas']); ?></td>

                            <td><?php echo htmlspecialchars($row['correo_recepcionistas']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefono_recepcionistas']); ?></td>
                            <td>
                                <a href="recepcion-herr.php?editar_id=<?php echo $row['id_recepcionistas']; ?>" class="btn">Editar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>

<?php mysqli_close($conexion); ?>
