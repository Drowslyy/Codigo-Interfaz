<?php
session_start();
include('includes/connection_db.php'); // Conexión a la base de datos

if (isset($_POST['correo']) && isset($_POST['contraseña'])) {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Consultar en la tabla de administradores (usando el nombre correcto de la columna 'correo_administradores')
    $sql_admin = "SELECT * FROM administradores WHERE correo_administradores = ?"; 
    $stmt_admin = $conn->prepare($sql_admin);
    $stmt_admin->bind_param('s', $correo);
    $stmt_admin->execute();
    $result_admin = $stmt_admin->get_result();

    if ($result_admin->num_rows > 0) {
        $row_admin = $result_admin->fetch_assoc();

        // Verificar la contraseña
        if ($contraseña == $row_admin['contraseña_administradores']) { // Usando 'contraseña_administradores'
            // Guardar la sesión
            $_SESSION['admin_id'] = $row_admin['id_administradores']; // Usando 'id_administradores'
            $_SESSION['nombre_completo_admin'] = $row_admin['nombre_completo_administradores']; // Usando 'nombre_completo_administradores'
            header('Location: admin_dashboard.php'); // Redirigir al panel de administración
            exit();
        } else {
            echo "Contraseña incorrecta para el administrador.";
        }
    } else {
        echo "No se encontró el administrador con ese correo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Administrador</title>
</head>
<body>

    <h2>Iniciar sesión como Administrador</h2>

    <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>

    <form method="POST" action="">
        <label for="correo">Correo:</label>
        <input type="email" name="correo" required><br><br>

        <label for="contraseña">Contraseña:</label>
        <input type="password" name="contraseña" required><br><br>

        <button type="submit">Iniciar sesión</button>
    </form>

</body>
</html>
