<?php
session_start();

// Verificar si el recepcionista está logueado
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Conectar con la base de datos
$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Recuperar el ID del recepcionista logueado
$id_recepcionista = $_SESSION['recepcionista_id'];

// Recuperar la información del recepcionista desde la base de datos
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los valores del formulario
    $nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
    $correo = mysqli_real_escape_string($conexion, $_POST['correo']);
    $password = $_POST['password'];

    // Verificar si se proporcionó una nueva contraseña
    if (!empty($password)) {
        // Actualizar la contraseña sin encriptar en la base de datos
        $sql = "UPDATE recepcionistas SET nombre_completo_recepcionistas = ?, correo_recepcionistas = ?, contraseña_recepcionistas = ? WHERE id_recepcionistas = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "sssi", $nombre, $correo, $password, $id_recepcionista);
    } else {
        // Solo actualizar el nombre y correo si no se proporciona una nueva contraseña
        $sql = "UPDATE recepcionistas SET nombre_completo_recepcionistas = ?, correo_recepcionistas = ? WHERE id_recepcionistas = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $nombre, $correo, $id_recepcionista);
    }

    // Ejecutar la consulta y verificar si fue exitosa
    if (mysqli_stmt_execute($stmt)) {
        echo "Perfil actualizado exitosamente.";
    } else {
        echo "Error al actualizar el perfil: " . mysqli_error($conexion);
    }

    // Cerrar la conexión
    mysqli_stmt_close($stmt);
}

// Recuperar la información actual del recepcionista
$sql = "SELECT * FROM recepcionistas WHERE id_recepcionistas = ?";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_recepcionista);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$recepcionista = mysqli_fetch_assoc($resultado);

// Verificar si se encontró el recepcionista
if (!$recepcionista) {
    die("No se encontró el recepcionista en la base de datos.");
}

// Cerrar la conexión
mysqli_stmt_close($stmt);
mysqli_close($conexion);
?>
