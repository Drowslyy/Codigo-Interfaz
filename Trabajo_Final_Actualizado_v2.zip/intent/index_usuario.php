<?php
session_start();
include('includes/connection_db.php');

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}

// Obtener el ID del usuario desde la sesión
$usuario_id = $_SESSION['usuario_id'];

// Consultar la información del usuario logueado
$sql_cliente = "SELECT * FROM usuarios WHERE id_usuarios = ?";
$stmt_cliente = $conn->prepare($sql_cliente);
$stmt_cliente->bind_param('i', $usuario_id);
$stmt_cliente->execute();
$result_cliente = $stmt_cliente->get_result();

if ($result_cliente->num_rows > 0) {
    $row_cliente = $result_cliente->fetch_assoc();
    $nombre_completo = $row_cliente['nombre_completo_usuarios'];
    $correo = $row_cliente['correo_usuarios'];
} else {
    echo "No se encontró información del usuario.";
    exit();
}

// Obtener el ID del cliente (tabla clientes) relacionado con el usuario
$sql_id_cliente = "SELECT id_clientes, estado_membresia_clientes, fecha_inicio_membresia_clientes, membresia_id_clientes FROM clientes WHERE usuario_id_clientes = ?";
$stmt_id_cliente = $conn->prepare($sql_id_cliente);
$stmt_id_cliente->bind_param('i', $usuario_id);
$stmt_id_cliente->execute();
$result_id_cliente = $stmt_id_cliente->get_result();

if ($result_id_cliente->num_rows > 0) {
    $row_id_cliente = $result_id_cliente->fetch_assoc();
    $cliente_id = $row_id_cliente['id_clientes'];
    $estado_membresia = $row_id_cliente['estado_membresia_clientes'];
    $fecha_inicio_membresia = $row_id_cliente['fecha_inicio_membresia_clientes'];
    $membresia_id = $row_id_cliente['membresia_id_clientes'];
} else {
    echo "No se encontró un cliente asociado.";
    exit();
}

// Consultar detalles de membresía si tiene una asignada
if ($membresia_id === NULL) {
    // Si no tiene membresía asignada
    $tipo_membresia = "Sin plan asignado";
} else {
    // Verificar si el id de membresía es válido
    $sql_membresia = "SELECT tipo_membresias FROM membresias WHERE id_membresias = ?";
    $stmt_membresia = $conn->prepare($sql_membresia);
    $stmt_membresia->bind_param('i', $membresia_id);
    $stmt_membresia->execute();
    $result_membresia = $stmt_membresia->get_result();

    if ($result_membresia->num_rows > 0) {
        $row_membresia = $result_membresia->fetch_assoc();
        $tipo_membresia = $row_membresia['tipo_membresias'];
    } else {
        // Si no se encuentra el tipo de membresía, asignar un valor por defecto
        $tipo_membresia = "Sin plan asignado";
    }
}

// Consultar actividades disponibles
$sql_actividades = "SELECT * FROM actividades";
$stmt_actividades = $conn->prepare($sql_actividades);
$stmt_actividades->execute();
$result_actividades = $stmt_actividades->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil del Cliente</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-header h1 {
            font-size: 36px;
            color: #0284C7;
            margin-bottom: 10px;
        }

        .profile-header p {
            font-size: 18px;
            color: #555;
        }

        .profile-info, .historial-pagos, .reservas, .actividades, .membresia {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .profile-info h3, .historial-pagos h3, .reservas h3, .actividades h3, .membresia h3 {
            font-size: 24px;
            color: #0284C7;
            margin-bottom: 15px;
        }

        .profile-info p, .historial-pagos p, .reservas p, .actividades p, .membresia p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .btn {
            display: inline-block;
            background-color: #0284C7;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0270A1;
        }

        .acciones {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

    <div class="container">
        <!-- Botones de acción -->
        <div class="acciones">
            <a href="editar_perfil_usuario.php" class="btn">Editar perfil</a>
            <a href="index_login.php" class="btn">Volver</a>
            <a href="logout.php" class="btn">Cerrar sesión</a>
        </div>

        <div class="profile-header">
            <h1>Bienvenido, <?php echo htmlspecialchars($nombre_completo); ?>!</h1>
            <p>Información de tu cuenta</p>
        </div>

        <div class="profile-info">
            <h3>Información de tu cuenta</h3>
            <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($correo); ?></p>
            <p><strong>Nombre completo:</strong> <?php echo htmlspecialchars($nombre_completo); ?></p>
        </div>

        <div class="membresia">
            <h3>Estado de tu membresía</h3>
            <p><strong>Tipo de membresía:</strong> <?php echo htmlspecialchars($tipo_membresia); ?></p>
            <p><strong>Estado:</strong> <?php echo htmlspecialchars($estado_membresia); ?></p>
            <p><strong>Fecha de inicio:</strong> <?php echo htmlspecialchars($fecha_inicio_membresia); ?></p>
        </div>

        <div class="actividades">
            <h3>Actividades disponibles</h3>
            <?php
            if ($result_actividades->num_rows > 0) {
                while ($row_actividad = $result_actividades->fetch_assoc()) {
                    echo "<p><strong>" . htmlspecialchars($row_actividad['nombre']) . ":</strong> " . htmlspecialchars($row_actividad['descripcion']) . " <br><em>" . htmlspecialchars($row_actividad['horario']) . "</em></p>";
                }
            } else {
                echo "<p>No hay actividades disponibles en este momento.</p>";
            }
            ?>
        </div>

        <div class="historial-pagos">
            <h3>Historial de Pagos</h3>
            <?php
            $sql_pagos = "SELECT fecha_pago_pagos, monto_pagos FROM pagos WHERE cliente_id_pagos = ?";
            $stmt_pagos = $conn->prepare($sql_pagos);
            $stmt_pagos->bind_param('i', $cliente_id);
            $stmt_pagos->execute();
            $result_pagos = $stmt_pagos->get_result();

            if ($result_pagos->num_rows > 0) {
                while ($row_pago = $result_pagos->fetch_assoc()) {
                    $fecha_pago = isset($row_pago['fecha_pago_pagos']) ? htmlspecialchars($row_pago['fecha_pago_pagos']) : 'Fecha no disponible';
                    $monto_pago = isset($row_pago['monto_pagos']) ? '$' . number_format($row_pago['monto_pagos'], 2) : 'Monto no disponible';
                    echo "<p>Pago realizado el: " . $fecha_pago . " - Monto: " . $monto_pago . "</p>";
                }
            } else {
                echo "<p>No se encontraron registros de pagos.</p>";
            }
            ?>
        </div>

        

</body>
</html>

<?php
$conn->close();
?>
