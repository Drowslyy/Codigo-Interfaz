<?php
session_start();
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir la conexión a la base de datos y funciones comunes
require_once 'includes/connection_db.php';  // Asegúrate de que este archivo está siendo incluido correctamente
require_once 'functions.php';  // Funciones que dependen de la conexión

// Verificar si se pasó un ID de actividad
if (!isset($_GET['id'])) {
    header("Location: crear_gestionar_actividades.php");
    exit();
}

$id_actividad = $_GET['id'];
$actividad = obtenerDetallesActividad($id_actividad);  // Cambiar el nombre de la función

if (!$actividad) {
    // Si no se encuentra la actividad, redirigir de vuelta
    header("Location: crear_gestionar_actividades.php");
    exit();
}

// Procesar el formulario de edición
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';
    $horario = $_POST['horario'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';
    $hora_fin = $_POST['hora_fin'] ?? '';

    // Actualizar la actividad
    actualizarDetallesActividad($id_actividad, $nombre, $descripcion, $horario, $hora_inicio, $hora_fin);  // Cambiar el nombre de la función

    header("Location: crear_gestionar_actividades.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Actividad - Central Gym</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .contenedor {
            width: 80%;
            max-width: 800px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .formulario-actividad {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-size: 1.1em;
            color: #333;
        }

        input[type="text"],
        input[type="time"],
        textarea {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        textarea {
            height: 120px;
        }

        button {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        .btn-volver {
            display: inline-block;
            margin-top: 20px;
            text-align: center;
            text-decoration: none;
            background-color: #dc3545;
            color: white;
            padding: 10px 15px;
            border-radius: 4px;
            font-size: 1em;
            transition: background-color 0.3s ease;
        }

        .btn-volver:hover {
            background-color: #c82333;
        }

        /* Estilo para los campos con errores (si los hay) */
        input:invalid, textarea:invalid {
            border-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="contenedor">
        <h1>Editar Actividad</h1>

        <form method="POST" class="formulario-actividad">
            <input type="hidden" name="id_actividad" value="<?php echo htmlspecialchars($actividad['id']); ?>">
            
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($actividad['nombre']); ?>" required>

            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required><?php echo htmlspecialchars($actividad['descripcion']); ?></textarea>

            <label for="horario">Horario:</label>
            <input type="text" id="horario" name="horario" value="<?php echo htmlspecialchars($actividad['horario']); ?>" required>

            <label for="hora_inicio">Hora de Inicio:</label>
            <input type="time" id="hora_inicio" name="hora_inicio" value="<?php echo htmlspecialchars($actividad['hora_inicio']); ?>" required>

            <label for="hora_fin">Hora de Fin:</label>
            <input type="time" id="hora_fin" name="hora_fin" value="<?php echo htmlspecialchars($actividad['hora_fin']); ?>" required>

            <button type="submit">Guardar Cambios</button>
        </form>

        <a href="crear_gestionar_actividades.php" class="btn-volver">Cancelar</a>
    </div>
</body>
</html>

