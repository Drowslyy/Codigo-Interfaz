<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id']) && !isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Incluir las funciones para obtener las actividades
require_once 'functions.php';
$actividades = obtenerActividades();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividades Disponibles</title>
    <link rel="stylesheet" href="style/style_actividades.css">
</head>
<body>
    <header>
        <h1>Actividades Disponibles</h1>
        <a href="index_login.php" class="btn-volver">Volver al Inicio</a>
    </header>
    <main class="contenedor">
        <?php if (!empty($actividades)): ?>
            <ul class="lista-actividades">
                <?php foreach ($actividades as $actividad): ?>
                    <li>
                        <h3><?php echo htmlspecialchars($actividad['nombre']); ?></h3>
                        <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                        <span>Horario: <?php echo htmlspecialchars($actividad['horario']); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No hay actividades disponibles en este momento.</p>
        <?php endif; ?>
    </main>
</body>
</html>
