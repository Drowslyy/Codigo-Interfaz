<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$host = '154.38.166.102';
$port = '3306';
$db = 'g1_sgg';
$user = 'fmario';
$password = 'fmario';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar con la base de datos: " . $e->getMessage());
}

// Obtener información de pagos
$query = "
    SELECT 
        p.id_pagos,
        u.nombre_completo_usuarios,
        u.correo_usuarios,
        m.tipo_membresias,
        m.precio_membresias,
        m.duracion_membresias,
        p.fecha_pago_pagos,
        DATE_ADD(p.fecha_pago_pagos, INTERVAL m.duracion_membresias DAY) AS fecha_fin_membresia
    FROM pagos p
    INNER JOIN clientes c ON p.cliente_id_pagos = c.id_clientes
    INNER JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios
    INNER JOIN membresias m ON p.membresia_id_pagos = m.id_membresias
    ORDER BY p.id_pagos;
";

$stmt = $pdo->query($query);
$pagos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Exportar a PDF
if (isset($_GET['export_pdf'])) {
    require_once 'pdf_generator.php'; // Asumiendo que generas el PDF en un archivo separado
    generatePDF($pagos); // Función que generará el archivo PDF
    exit();
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagos</title>
    <link rel="stylesheet" href="style/style_clienteadmin.css">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
    <a href="javascript:history.back()" class="btn-volver">Volver Atrás</a>
</head>
<body>
    <h1>Pagos</h1>
    <table>
        <thead>
            <tr>
                <th>ID Pago</th>
                <th>Nombre Usuario</th>
                <th>Correo</th>
                <th>Tipo de Membresía</th>
                <th>Precio</th>
                <th>Fecha de Pago</th>
                <th>Fecha Fin Membresía</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pagos as $pago): ?>
                <tr>
                    <td><?= htmlspecialchars($pago['id_pagos']) ?></td>
                    <td><?= htmlspecialchars($pago['nombre_completo_usuarios']) ?></td>
                    <td><?= htmlspecialchars($pago['correo_usuarios']) ?></td>
                    <td><?= htmlspecialchars($pago['tipo_membresias']) ?></td>
                    <td><?= htmlspecialchars(number_format($pago['precio_membresias'], 2)) ?></td>
                    <td><?= htmlspecialchars($pago['fecha_pago_pagos']) ?></td>
                    <td><?= htmlspecialchars($pago['fecha_fin_membresia']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Botón para exportar a PDF -->
    <div class="export-buttons">
        <a href="?export_pdf=true" class="btn-export">Exportar a PDF</a>
    </div>
</body>
</html>
