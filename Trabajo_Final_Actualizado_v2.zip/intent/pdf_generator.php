<?php
require('fpdf.php');  // Asegúrate de que fpdf.php esté en la misma carpeta

function generatePDF($data) {
    // Crear una nueva instancia de FPDF
    $pdf = new FPDF();
    $pdf->AddPage();
    
    // Usar la fuente Helvetica (debes tener el archivo helvetica.php en la carpeta font)
    $pdf->AddFont('Helvetica', '', 'helvetica.php');  // Aquí se agrega la fuente Helvetica
    
    // Establecer la fuente (ahora puedes usar Helvetica)
    $pdf->SetFont('Helvetica', '', 10); // Fuente más pequeña para reducir el tamaño general
    
    // Agregar título
    $pdf->Cell(190, 10, 'Reporte de Pagos', 0, 1, 'C');
    $pdf->Ln(10); // Salto de línea
    
    // Agregar encabezados de la tabla con anchos reducidos
    $pdf->Cell(25, 10, 'ID Pago', 1);
    $pdf->Cell(40, 10, 'Nombre Usuario', 1);
    $pdf->Cell(40, 10, 'Correo', 1);
    $pdf->Cell(30, 10, 'Tipo Membresía', 1);
    $pdf->Cell(25, 10, 'Precio', 1);
    $pdf->Cell(25, 10, 'Fecha de Pago', 1);
    $pdf->Cell(25, 10, 'Fecha Fin Membresía', 1);
    $pdf->Ln();
    
    // Llenar la tabla con los datos
    foreach ($data as $row) {
        $pdf->Cell(25, 10, $row['id_pagos'], 1);
        $pdf->Cell(40, 10, $row['nombre_completo_usuarios'], 1);
        $pdf->Cell(40, 10, $row['correo_usuarios'], 1);
        $pdf->Cell(30, 10, $row['tipo_membresias'], 1);
        $pdf->Cell(25, 10, '$' . number_format($row['precio_membresias'], 2), 1);
        $pdf->Cell(25, 10, $row['fecha_pago_pagos'], 1);
        $pdf->Cell(25, 10, $row['fecha_fin_membresia'], 1);
        $pdf->Ln();
    }
    
    // Generar el PDF y ofrecerlo para descarga
    $pdf->Output('D', 'reporte_pagos.pdf');
}

?>
