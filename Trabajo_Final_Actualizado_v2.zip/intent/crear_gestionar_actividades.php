<?php
session_start();
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir funciones comunes
require_once 'functions.php';

// Recuperar datos del recepcionista
$id_recepcionista = $_SESSION['recepcionista_id'];
$recepcionista = obtenerRecepcionista($id_recepcionista);

// Procesar formulario de creación/edición
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'] ?? '';
    $descripcion = $_POST['descripcion'] ?? '';
    $horario = $_POST['horario'] ?? '';
    $hora_inicio = $_POST['hora_inicio'] ?? '';  // Obtener el valor de hora_inicio
    $hora_fin = $_POST['hora_fin'] ?? '';        // Obtener el valor de hora_fin
    $id_actividad = $_POST['id_actividad'] ?? null;

    if ($id_actividad) {
        // Actualizar actividad existente
        modificarActividad($id_actividad, $nombre, $descripcion, $horario, $hora_inicio, $hora_fin);
    } else {
        // Crear nueva actividad
        registrarNuevaActividad($nombre, $descripcion, $horario, $hora_inicio, $hora_fin);
    }

    header("Location: crear_gestionar_actividades.php");
    exit();
}

// Eliminar actividad
if (isset($_GET['eliminar'])) {
    $id_actividad = $_GET['eliminar'];
    eliminarActividad($id_actividad);

    header("Location: crear_gestionar_actividades.php");
    exit();
}

// Obtener todas las actividades
$actividades = obtenerActividades();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Actividades</title>
    <link rel="stylesheet" href="style/style_clienteadmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="contenedor">
        <h1>Gestionar Actividades</h1>
        
        <form method="POST" class="formulario-actividad">
            <h2>Crear o Editar Actividad</h2>
            <input type="hidden" name="id_actividad" value="">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" required></textarea>
            <label for="horario">Horario:</label>
            <input type="text" id="horario" name="horario" required>
            <label for="hora_inicio">Hora de inicio:</label>
            <input type="time" id="hora_inicio" name="hora_inicio" required>
            <label for="hora_fin">Hora de fin:</label>
            <input type="time" id="hora_fin" name="hora_fin" required>
            <button type="submit">Guardar</button>
        </form>

        <h2>Lista de Actividades</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Horario</th>
                    <th>Hora de inicio</th>
                    <th>Hora de fin</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($actividades as $actividad): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($actividad['id']); ?></td>
                        <td><?php echo htmlspecialchars($actividad['nombre']); ?></td>
                        <td><?php echo htmlspecialchars($actividad['descripcion']); ?></td>
                        <td><?php echo htmlspecialchars($actividad['horario']); ?></td>
                        <td><?php echo htmlspecialchars($actividad['hora_inicio']); ?></td>
                        <td><?php echo htmlspecialchars($actividad['hora_fin']); ?></td>
                        <td>
                            <a href="editar_actividad.php?id=<?php echo $actividad['id']; ?>">Editar</a>
                            <a href="crear_gestionar_actividades.php?eliminar=<?php echo $actividad['id']; ?>" onclick="return confirm('¿Estás seguro de eliminar esta actividad?');">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <a href="panel_recepcionista.php" class="btn-volver">Volver al panel</a>
    </div>
</body>
</html>
