<?php
session_start();
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir funciones comunes
require_once 'functions.php';

// Variables para mensajes y resultados
$mensaje = "";
$reservas_cliente = [];

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_cliente = $_POST['id_cliente'] ?? '';

    if (!empty($id_cliente)) {
        // Buscar reservas asociadas al cliente
        $reservas_cliente = obtenerReservasPorCliente($id_cliente);

        if (empty($reservas_cliente)) {
            $mensaje = "No se encontraron reservas para el cliente con ID: $id_cliente.";
        }
    } else {
        $mensaje = "Por favor, ingresa un ID de cliente válido.";
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Reservas - Central Gym</title>
    <link rel="stylesheet" href="style/panel_recepcionista.css">
</head>
<body>
    <div class="contenedor">
        <h2>Buscar Reservas de Cliente</h2>
        
        <form action="buscar_reservas.php" method="POST">
            <label for="id_cliente">ID del Cliente:</label>
            <input type="text" id="id_cliente" name="id_cliente" placeholder="Ingrese el ID del cliente">
            <button type="submit">Buscar</button>
        </form>

        <?php if ($mensaje): ?>
            <p class="mensaje"><?php echo htmlspecialchars($mensaje); ?></p>
        <?php endif; ?>

        <?php if (!empty($reservas_cliente)): ?>
            <h3>Reservas encontradas:</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID Reserva</th>
                        <th>Fecha</th>
                        <th>Hora</th>
                        <th>Detalles</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservas_cliente as $reserva): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reserva['id_reserva']); ?></td>
                            <td><?php echo htmlspecialchars($reserva['fecha']); ?></td>
                            <td><?php echo htmlspecialchars($reserva['hora']); ?></td>
                            <td><?php echo htmlspecialchars($reserva['detalles']); ?></td>
                            <td>
                                <!-- Botón para editar reserva -->
                                <form action="editar_reserva.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id_reserva" value="<?php echo htmlspecialchars($reserva['id_reserva']); ?>">
                                    <button type="submit" class="btn-editar">Editar</button>
                                </form>

                                <!-- Botón para borrar reserva -->
                                <form action="borrar_reserva.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="id_reserva" value="<?php echo htmlspecialchars($reserva['id_reserva']); ?>">
                                    <button type="submit" class="btn-borrar" onclick="return confirm('¿Estás seguro de que deseas borrar esta reserva?');">Borrar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</body>
</html>