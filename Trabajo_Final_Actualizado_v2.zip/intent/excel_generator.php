<?php
// Incluir la librería PhpSpreadsheet
require 'vendor/autoload.php'; // Si usas Composer para instalar PhpSpreadsheet

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Función para generar y descargar el archivo Excel
function generateExcel($data) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();
    
    // Títulos de las columnas
    $sheet->setCellValue('A1', 'ID Pago');
    $sheet->setCellValue('B1', 'Nombre Usuario');
    $sheet->setCellValue('C1', 'Correo');
    $sheet->setCellValue('D1', 'Tipo Membresía');
    $sheet->setCellValue('E1', 'Precio');
    $sheet->setCellValue('F1', 'Fecha de Pago');
    $sheet->setCellValue('G1', 'Fecha Fin Membresía');
    
    // Llenar con los datos
    $row = 2;
    foreach ($data as $item) {
        $sheet->setCellValue('A' . $row, $item['id_pagos']);
        $sheet->setCellValue('B' . $row, $item['nombre_completo_usuarios']);
        $sheet->setCellValue('C' . $row, $item['correo_usuarios']);
        $sheet->setCellValue('D' . $row, $item['tipo_membresias']);
        $sheet->setCellValue('E' . $row, $item['precio_membresias']);
        $sheet->setCellValue('F' . $row, $item['fecha_pago_pagos']);
        $sheet->setCellValue('G' . $row, $item['fecha_fin_membresia']);
        $row++;
    }
    
    // Descargar el archivo Excel
    $writer = new Xlsx($spreadsheet);
    $fileName = 'reporte_pagos.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $fileName . '"');
    header('Cache-Control: max-age=0');
    $writer->save('php://output');
}
?>
