<?php
function conectarBaseDatos() {
    $conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
    if (!$conexion) {
        die("Conexión fallida: " . mysqli_connect_error());
    }
    return $conexion;
}

// Función para crear una nueva actividad
function registrarNuevaActividad($nombre, $descripcion, $horario, $hora_inicio, $hora_fin) {
    $conexion = conectarBaseDatos();

    // Preparar la consulta con parámetros
    $stmt = $conexion->prepare("INSERT INTO actividades (nombre, descripcion, horario, hora_inicio, hora_fin) 
                                VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nombre, $descripcion, $horario, $hora_inicio, $hora_fin);
    $stmt->execute();
    $stmt->close();
}





// Función para actualizar una actividad existente
function modificarActividad($id_actividad, $nombre, $descripcion, $horario, $hora_inicio, $hora_fin) {
    $conexion = conectarBaseDatos();
    $stmt = $conexion->prepare("UPDATE actividades SET nombre = ?, descripcion = ?, horario = ?, hora_inicio = ?, hora_fin = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $nombre, $descripcion, $horario, $hora_inicio, $hora_fin, $id_actividad);  // Agregar hora_fin
    $stmt->execute();
    $stmt->close();
}



// Función para obtener los detalles de una actividad por ID (con nombre modificado)
function obtenerDetallesActividad($id) {
    $conexion = conectarBaseDatos(); // Establece la conexión

    // Preparar la consulta para obtener la actividad
    $sql = "SELECT * FROM actividades WHERE id = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->bind_param("i", $id);  // "i" para entero
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();  // Retorna la actividad
    } else {
        return false;  // No se encuentra la actividad
    }
}


// Función para obtener los detalles de una actividad por ID


// Función para actualizar los detalles de la actividad (con nombre modificado)
function actualizarDetallesActividad($id, $nombre, $descripcion, $horario, $hora_inicio, $hora_fin) {
    global $conn;  // Asegúrate de que $conn esté accesible

    // Preparar la consulta para actualizar la actividad
    $sql = "UPDATE actividades SET nombre = ?, descripcion = ?, horario = ?, hora_inicio = ?, hora_fin = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $nombre, $descripcion, $horario, $hora_inicio, $hora_fin, $id);  // Asegúrate de que los tipos de parámetros son correctos
    $stmt->execute();
    $stmt->close();
}


function obtenerRecepcionista($id_recepcionista) {
    $conexion = conectarBaseDatos();
    $sql = "SELECT * FROM recepcionistas WHERE id_recepcionistas = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "i", $id_recepcionista);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);
    $recepcionista = mysqli_fetch_assoc($resultado);
    mysqli_stmt_close($stmt);
    mysqli_close($conexion);
    return $recepcionista;
}

function obtenerPagos($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT p.id_pagos, u.nombre_completo_usuarios AS nombre_cliente, p.monto_pagos, p.fecha_pago_pagos
            FROM pagos p
            LEFT JOIN clientes c ON p.cliente_id_pagos = c.id_clientes
            LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";
    if ($filtro) {
        $sql .= " WHERE u.nombre_completo_usuarios LIKE '%$filtro%' OR p.fecha_pago_pagos LIKE '%$filtro%'";
    }
    $sql .= " ORDER BY p.fecha_pago_pagos DESC";
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}

function obtenerReservas($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT r.id_reservas, u.nombre_completo_usuarios AS nombre_cliente, r.fecha_reserva_reservas
            FROM reservas r
            LEFT JOIN clientes c ON r.cliente_id_reservas = c.id_clientes
            LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";
    if ($filtro) {
        $sql .= " WHERE u.nombre_completo_usuarios LIKE '%$filtro%' OR r.fecha_reserva_reservas LIKE '%$filtro%'";
    }
    $sql .= " ORDER BY r.fecha_reserva_reservas DESC";
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}

function obtenerUsuarios($filtro = '') {
    $conexion = conectarBaseDatos();
    $sql = "SELECT * FROM usuarios";
    if ($filtro) {
        $sql .= " WHERE nombre_completo_usuarios LIKE '%$filtro%' OR correo_usuarios LIKE '%$filtro%'";
    }
    $result = mysqli_query($conexion, $sql);
    mysqli_close($conexion);
    return $result;
}

function obtenerActividades() {
    // Conectar a la base de datos y devolver todas las actividades
    $conexion = conectarBaseDatos();
    $sql = "SELECT * FROM actividades";
    $resultado = $conexion->query($sql);
    return $resultado->fetch_all(MYSQLI_ASSOC);
}

function crearActividad($nombre, $descripcion, $horario) {
    $conexion = conectarBaseDatos();
    $stmt = $conexion->prepare("INSERT INTO actividades (nombre, descripcion, horario) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $descripcion, $horario);
    $stmt->execute();
    $stmt->close();
}

function actualizarActividad($id, $nombre, $descripcion, $horario) {
    $conexion = conectarBaseDatos();
    $stmt = $conexion->prepare("UPDATE actividades SET nombre = ?, descripcion = ?, horario = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nombre, $descripcion, $horario, $id);
    $stmt->execute();
    $stmt->close();
}

function eliminarActividad($id) {
    $conexion = conectarBaseDatos();
    $stmt = $conexion->prepare("DELETE FROM actividades WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
function obtenerActividadPorId($id) {
    $conexion = conectarBaseDatos();
    $stmt = $conexion->prepare("SELECT * FROM actividades WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    return $resultado->fetch_assoc();
}

?>
