<?php
// Include your database connection
include('includes/connection_db.php');

// Fetch membership data
$sql = "SELECT * FROM membresias";
$result = $conn->query($sql);

// Check if results are returned
if ($result->num_rows > 0) {
    $membresias = [];
    while($row = $result->fetch_assoc()) {
        $membresias[] = $row; // Store each membership in the array
    }
} else {
    $membresias = []; // If no results are found, set an empty array
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym</title>
    <link rel="stylesheet" href="style/style_index_usuario.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .membresias-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .membresia-card {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 20px;
            width: calc(33% - 20px); /* Adjust this for responsiveness */
            background-color: #f9f9f9;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .membresia-card h3 {
            margin-top: 0;
            font-size: 1.5em;
            color: #333;
        }

        .membresia-card p {
            color: #555;
        }

        .membresia-card a {
            display: inline-block;
            margin-top: 10px;
            text-decoration: none;
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .membresia-card a:hover {
            background-color: #0056b3;
        }

        /* Estilo adicional para la descripción */
        .header-txt {
            flex: 1;
        }

        .header-img {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .header-img img {
            max-width: 100%;
            height: auto;
        }

        .header-content.container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .about-txt h2, .servicios h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .servicios-cont.container {
            display: flex;
            justify-content: space-around;
        }

        .servicios-1 {
            width: 30%;
            text-align: center;
        }

    </style>
</head>
<body>
    <header class="header">
        <div class="menu container">
            <a href="index_login.php" class="logo">GYM</a>

            <nav class="navbar">
                <ul>
                    <li><a href="registor.php">Registrarse</a></li>
                    <li><a href="login.php">Inciar Sesión</a></li>
                </ul>
            </nav>
        </div>

        <div class="header-content container">
            <div class="header-txt">
                <h1>Bienvenido a Central Gym</h1>
                <p>
                    Nos apasiona ayudarte a alcanzar tus metas de bienestar físico y mental. Nuestro equipo altamente calificado y motivado está comprometido en brindarte el mejor ambiente de entrenamiento, donde cada miembro puede desarrollarse al máximo. Ya sea que busques mejorar tu resistencia, tonificar tu cuerpo o encontrar equilibrio mental, estamos aquí para apoyarte en cada paso de tu camino.
                    ¡Únete a nuestra comunidad y transforma tu vida con nosotros!
                </p>
            </div>
        </div>
    </header>

    <section class="about container">
        <div class="about-txt">
            <h2>Acerca de Nosotros</h2>
            <p>
                En Central Gym, nos apasiona ayudarte a alcanzar tus metas de bienestar físico y mental. Con un equipo altamente calificado y motivado, ofrecemos un ambiente de entrenamiento inclusivo, donde cada miembro puede desarrollar su potencial al máximo. Ya sea que estés buscando mejorar tu resistencia, tonificar tu cuerpo o encontrar equilibrio mental, estamos aquí para apoyarte en cada paso del camino. ¡Únete a nuestra comunidad y transforma tu vida con nosotros!
            </p>
        </div>
    </section>

    <!-- Membresías -->
    <section class="membresias">
        <h2>Elige tu Membresía</h2>
        <div class="membresias-container">
            <?php foreach ($membresias as $membresia): ?>
                <div class="membresia-card">
                    <h3><?php echo $membresia['tipo_membresias']; ?></h3>
                    <p><strong>Descripción:</strong> <?php echo $membresia['beneficios_membresias']; ?></p>
                    <p><strong>Precio:</strong> $<?php echo $membresia['precio_membresias']; ?></p>
                    <a href="registro.php?id=<?php echo $membresia['id_membresias']; ?>">Ver Detalles</a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <main class="servicios">
        <h2>Servicios</h2>
        <div class="servicios-cont container">
            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador Personal</h3>
                <h7>Si buscas un enfoque más personalizado, nuestros entrenadores personales son expertos en diseñar rutinas adaptadas a tus objetivos y necesidades.</h7>
            </div>
            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador de Fuerza y Acondicionamiento</h3>
                <h7>¿Quieres mejorar tu fuerza y resistencia? Nuestros entrenadores especializados en fuerza y acondicionamiento te ayudarán a alcanzar un rendimiento físico excepcional.</h7>
            </div>
            <div class="servicios-1">
                <i class="fa-solid fa-user"></i>
                <h3>Instructor de Yoga o Pilates</h3>
                <h7>El bienestar no solo es físico, también es mental. Si buscas mejorar tu flexibilidad, reducir el estrés o encontrar el equilibrio entre cuerpo y mente, nuestros instructores de yoga y pilates son la opción perfecta.</h7>
            </div>
        </div>
    </main>

    <section class="formulario container">
        <form method="post" autocomplete="off">
            <h2>Contáctanos</h2>
            <div class="input-group">
                <div class="input-container">
                    <input type="text" name="nombre" placeholder="Nombre Completo" required>
                    <i class="fa-solid fa-user"></i>
                </div>
                <div class="input-container">
                    <input type="tel" name="phone" placeholder="9 XXXX XXXX" required>
                    <i class="fa-solid fa-phone"></i>
                </div>
                <div class="input-container">
                    <input type="text" name="Peso" placeholder="X Kg" required>
                    <i class="fa-solid fa-weight-hanging"></i>
                </div>
                <div class="input-container">
                    <input type="text" name="Altura" placeholder="X cm" required>
                    <i class="fa-solid fa-ruler"></i>
                </div>
                <div class="input-container">
                    <textarea name="consulta" placeholder="Consulta..." required></textarea>
                </div>
                <button type="submit">Enviar</button>
            </div>
        </form>
    </section>

    <footer class="footer">
        <div class="footer-container container">
            <div class="footer-info">
                <h2>Información</h2>
                <p>¡Síguenos en redes sociales y mantente al día con nuestras últimas promociones y noticias!</p>
            </div>
            <div class="footer-socials">
                <a href="https://facebook.com">Facebook</a>
                <a href="https://instagram.com">Instagram</a>
                <a href="https://wa.me/123456789">WhatsApp</a>
            </div>
        </div>
    </footer>

</body>
</html>
