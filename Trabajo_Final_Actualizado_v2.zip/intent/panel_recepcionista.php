<?php
session_start();
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Incluir funciones comunes
require_once 'functions.php';

// Recuperar datos del recepcionista
$id_recepcionista = $_SESSION['recepcionista_id'];
$recepcionista = obtenerRecepcionista($id_recepcionista);

// Consultas de acciones del recepcionista
$pagos = obtenerPagos();
$reservas = obtenerReservas();
$usuarios = obtenerUsuarios();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Recepcionista - Central Gym</title>
    <link rel="stylesheet" href="style/panel_recepcionista.css">
</head>
<body>
    <div class="bienvenida">
        <h2>Bienvenido/a, <?php echo htmlspecialchars($recepcionista['nombre_completo_recepcionistas']); ?></h2>
        <p>Gestiona tus actividades desde el panel.</p>
    </div>

    <div class="cuadros-container">
        <a href="historial_pagos_recepcionista.php" class="cuadro">
            <h3>Historial de Pagos</h3>
            <p>Consulta los pagos realizados por los clientes.</p>
        </a>
        <a href="reservas.php" class="cuadro">
            <h3>Reservas</h3>
            <p>Revisa y gestiona las reservas activas.</p>
        </a>
        <a href="listaclientes.php" class="cuadro">
            <h3>Clientes</h3>
            <p>Administra los datos de los clientes del gimnasio.</p>
        </a>

        <a href="crear_gestionar_actividades.php" class="cuadro">
            <h3>Crear y Gestionar Actividades</h3>
            <p>Creación y gestión de actividades.</p>
        </a>     

    <a href="logout.php" class="btn-cerrar-sesion">Cerrar sesión</a>
</body>
</html>
