<?php
session_start();

// Incluir la conexión a la base de datos
require_once 'includes/connection_db.php';

// Verificar si el usuario está logueado (usuario o administrador)
if (!isset($_SESSION['usuario_id']) && !isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit();
}

// Función para obtener las actividades disponibles
function obtenerActividades($conn) {
    $sql = "SELECT * FROM actividades";
    $result = $conn->query($sql);
    
    if (!$result) {
        die('Error al obtener actividades: ' . $conn->error);
    }
    
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Función para obtener los detalles de una actividad por ID
function obtenerActividadPorId($conn, $actividad_id) {
    $sql = "SELECT * FROM actividades WHERE id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die('Error al preparar la consulta: ' . $conn->error);
    }
    
    $stmt->bind_param("i", $actividad_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

// Función para obtener el id_cliente de un usuario
function obtenerClienteId($conn, $usuario_id) {
    $sql = "SELECT id_clientes FROM clientes WHERE id_usuario = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $cliente = $result->fetch_assoc();
    return $cliente ? $cliente['id_clientes'] : null;
}

// Función para verificar si el usuario ya tiene una reserva para la actividad
function verificarReservaExistente($conn, $cliente_id, $actividad_id) {
    $sql = "SELECT * FROM reservas WHERE cliente_id_reservas = ? AND actividad_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $cliente_id, $actividad_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

// Función para registrar una reserva en la base de datos
function registrarReserva($conn, $cliente_id, $actividad_id, $fecha_reserva, $hora_inicio, $hora_fin) {
    $sql = "INSERT INTO reservas (cliente_id_reservas, actividad_id, fecha_reserva_reservas, hora_inicio_reservas, hora_fin_reservas)
            VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die('Error al preparar la consulta: ' . $conn->error);
    }
    
    $stmt->bind_param("iisss", $cliente_id, $actividad_id, $fecha_reserva, $hora_inicio, $hora_fin);
    return $stmt->execute();
}

// Obtener las actividades disponibles
$actividades = obtenerActividades($conn);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['actividad_id'])) {
    $actividad_id = $_POST['actividad_id'];
    $usuario_id = $_SESSION['usuario_id'];  // Obtener el ID del usuario logueado
    $fecha_reserva = date('Y-m-d');  // Fecha actual para la reserva
    
    // Obtener el id_cliente del usuario
    $cliente_id = obtenerClienteId($conn, $usuario_id);
    
    if ($cliente_id) {
        // Verificar si el usuario ya tiene una reserva para esta actividad
        if (verificarReservaExistente($conn, $cliente_id, $actividad_id)) {
            $mensaje = "Ya estás registrado en esta actividad.";
        } else {
            // Obtener los detalles de la actividad
            $actividad = obtenerActividadPorId($conn, $actividad_id);

            // Verificar si la actividad existe y tiene horarios definidos
            if ($actividad) {
                $hora_inicio = $actividad['hora_inicio'];
                $hora_fin = $actividad['hora_fin'];

                if ($hora_inicio && $hora_fin) {
                    // Registrar la reserva para el usuario
                    $resultado = registrarReserva($conn, $cliente_id, $actividad_id, $fecha_reserva, $hora_inicio, $hora_fin);

                    if ($resultado) {
                        $mensaje = "Te has registrado con éxito en la actividad.";
                    } else {
                        $mensaje = "Hubo un error al registrarte en la actividad.";
                    }
                } else {
                    $mensaje = "No se encontraron las horas de la actividad.";
                }
            } else {
                $mensaje = "Actividad no encontrada.";
            }
        }
    } else {
        $mensaje = "El usuario no está asociado a un cliente válido.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actividades Disponibles</title>
    <style>
        /* Estilos generales para el cuerpo */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            background-color: #007BFF;
            color: white;
            text-align: center;
            padding: 20px;
        }

        header h1 {
            margin: 0;
        }

        .btn-volver {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            margin-top: 10px;
            display: inline-block;
        }

        .btn-volver:hover {
            background-color: #218838;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin: 20px 0;
            border-radius: 5px;
            text-align: center;
        }

        .contenedor {
            padding: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .lista-actividades {
            list-style-type: none;
            padding: 0;
        }

        .lista-actividades li {
            background-color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .lista-actividades li:hover {
            transform: scale(1.05);
        }

        .lista-actividades h3 {
            font-size: 1.5em;
            margin: 0;
            color: #007BFF;
        }

        .lista-actividades p {
            font-size: 1.1em;
            color: #555;
        }

        .lista-actividades span {
            display: block;
            margin-top: 10px;
            font-weight: bold;
            color: #333;
        }

        .btn-registrar {
            background-color: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .btn-registrar:hover {
            background-color: #0056b3;
        }

        /* Estilo para pantallas pequeñas */
        @media (max-width: 768px) {
            .contenedor {
                padding: 10px;
            }

            .lista-actividades li {
                padding: 10px;
            }

            header {
                padding: 15px;
            }

            header h1 {
                font-size: 1.5em;
            }
        }
    </style>
</head>
<body>
    <header>
        <h1>Actividades Disponibles</h1>
        <a href="admin_dashboard.php" class="btn-volver">Volver al Inicio</a>
    </header>

    <?php if (isset($mensaje)): ?>
        <p class="success"><?php echo $mensaje; ?></p>
    <?php endif; ?>

    <main class="contenedor">
        <?php if (!empty($actividades)): ?>
            <ul class="lista-actividades">
                <?php foreach ($actividades as $actividad): ?>
                    <li>
                        <h3><?php echo htmlspecialchars($actividad['nombre']); ?></h3>
                        <p><?php echo htmlspecialchars($actividad['descripcion']); ?></p>
                        <span>Horario: <?php echo htmlspecialchars($actividad['hora_inicio']) . ' - ' . htmlspecialchars($actividad['hora_fin']); ?></span>

                        <form method="POST">
                            <input type="hidden" name="actividad_id" value="<?php echo $actividad['id']; ?>">
                            <button type="submit" class="btn-registrar">Editar</button>
                            <button type="submit" class="btn-registrar">Eliminar</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No hay actividades disponibles en este momento.</p>
        <?php endif; ?>
    </main>
</body>
</html>
