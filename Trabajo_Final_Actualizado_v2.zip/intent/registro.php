<?php
// Conexión a la base de datos
include('includes/connection_db.php');

if (isset($_POST['nombre_completo'], $_POST['correo_registro'], $_POST['contraseña_registro'], $_POST['telefono'], $_POST['direccion'], $_POST['fecha_nacimiento'])) {
    // Obtener y limpiar los datos del formulario
    $nombre_completo = htmlspecialchars(trim($_POST['nombre_completo']));
    $correo_registro = htmlspecialchars(trim($_POST['correo_registro']));
    $contraseña_registro = htmlspecialchars(trim($_POST['contraseña_registro']));
    $telefono = htmlspecialchars(trim($_POST['telefono']));
    $direccion = htmlspecialchars(trim($_POST['direccion']));
    $fecha_nacimiento = htmlspecialchars(trim($_POST['fecha_nacimiento']));

    // Validar que todos los campos estén llenos
    if (empty($nombre_completo) || empty($correo_registro) || empty($contraseña_registro) || empty($telefono) || empty($direccion) || empty($fecha_nacimiento)) {
        die("Todos los campos son obligatorios.");
    }

    // Establecer el valor de rol_usuarios y estado_registro
    $rol_registro = 1;  // El rol 'usuario' tiene el id_roles = 1
    $estado_registro = "activo"; // Asigna un estado predeterminado como "activo"

    // Foto de perfil (opcional)
    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
        // Subir la foto de perfil
        $foto_perfil = $_FILES['foto_perfil']['name'];
        $foto_perfil = str_replace(' ', '_', $foto_perfil); // Reemplazar espacios por guiones bajos

        // Validar que la foto sea un tipo permitido (por ejemplo, jpg, png)
        $allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];
        $file_type = $_FILES['foto_perfil']['type'];

        if (!in_array($file_type, $allowed_types)) {
            die("El archivo no es una imagen válida (solo JPG o PNG).");
        }

        // Validar tamaño máximo de archivo (por ejemplo, 2 MB)
        if ($_FILES['foto_perfil']['size'] > 2 * 1024 * 1024) {
            die("El archivo de la foto de perfil es demasiado grande. El tamaño máximo permitido es 2 MB.");
        }

        $target_dir = $_SERVER['DOCUMENT_ROOT'] . "/intent/uploads/";
        $target_file = $target_dir . basename($foto_perfil);

        // Verificar si el directorio existe, si no, crearlo
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        // Manejo de la subida del archivo
        if (!move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $target_file)) {
            die("Error al subir el archivo de la foto de perfil.");
        }
    } else {
        // Si no se subió ninguna foto, asignar un valor predeterminado
        $foto_perfil = NULL; // O una imagen predeterminada como 'default.jpg'
    }

    // Verificar si el correo ya está registrado
    $sql_check = "SELECT * FROM usuarios WHERE correo_usuarios = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param('s', $correo_registro);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "El correo electrónico ya está registrado.";
    } else {
        // Establecer la fecha actual para el registro
        $fecha_registro = date("Y-m-d H:i:s");

        // Insertar al nuevo usuario
        $sql_insert = "INSERT INTO usuarios (nombre_completo_usuarios, correo_usuarios, contraseña_usuarios, fecha_registro_usuarios, rol_usuarios, estado_usuarios, telefono_usuarios, direccion_usuarios, fecha_nacimiento_usuarios, foto_perfil_usuarios) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param('ssssssssss', $nombre_completo, $correo_registro, $contraseña_registro, $fecha_registro, $rol_registro, $estado_registro, $telefono, $direccion, $fecha_nacimiento, $foto_perfil);

        if ($stmt_insert->execute()) {
            echo '<script>
                    alert("Registro exitoso. Redirigiendo al login...");
                    window.location.href = "login.php"; 
                  </script>';
        } else {
            echo "Error al registrar el usuario.";
        }
    }

    // Cerrar los prepared statements
    $stmt_check->close();
    $stmt_insert->close();
}

// Cerrar la conexión a la base de datos
$conn->close();
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Usuario</title>
    <!-- Vincula el archivo CSS externo -->
    <link rel="stylesheet" href="style/style_register.css">
    <!-- Vincula Font Awesome para los iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <!-- Contenedor del formulario -->
    <div class="formulario">
        <form method="POST" action="" enctype="multipart/form-data">
            <h2>Registrar Usuario</h2>

            <!-- Campo Nombre completo con icono -->
            <div class="input-container">
                <i class="fas fa-user"></i>
                <input type="text" name="nombre_completo" placeholder="Nombre completo" required>
            </div>

            <!-- Campo Correo electrónico con icono -->
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="correo_registro" placeholder="Correo electrónico" required>
            </div>

            <!-- Campo Contraseña con icono -->
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="contraseña_registro" placeholder="Contraseña" required>
            </div>

            <!-- Campo Teléfono con icono -->
            <div class="input-container">
                <i class="fas fa-phone"></i>
                <input type="text" name="telefono" placeholder="Teléfono" required>
            </div>

            <!-- Campo Dirección con icono -->
            <div class="input-container">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="direccion" placeholder="Dirección" required>
            </div>

            <!-- Campo Fecha de nacimiento con icono -->
            <div class="input-container">
                <i class="fas fa-birthday-cake"></i>
                <input type="date" name="fecha_nacimiento" required>
            </div>

            <!-- Campo Foto de perfil -->
            <div class="input-container">
                <i class="fas fa-image"></i>
                <input type="file" name="foto_perfil" accept="image/*">
            </div>

            <!-- Botón de registro -->
            <button type="submit">Registrar</button>

            <!-- Enlace para volver al login -->
            <div class="volver-login">
                <p>¿Tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
            </div>

        </form>
    </div>

</body>
</html>
