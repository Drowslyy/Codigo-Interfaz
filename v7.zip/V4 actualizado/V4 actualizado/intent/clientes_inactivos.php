<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Consulta para obtener solo los clientes inactivos
$query = "
    SELECT * 
    FROM usuarios
    WHERE estado_usuarios = 'inactivo'
";
$resultado = mysqli_query($conexion, $query);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes Inactivos</title>
    <link rel="stylesheet" href="style/style_clienteadmin.css">
</head>
<body>
    <main>
        <section class="container">
            <h1>Clientes Inactivos</h1>
            <div class="button-group">
                <a href="clientes-herr.php" class="btn">Ver Clientes Activos</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Completo</th>
                        <th>Correo</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($resultado)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_completo_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['correo_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefono_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['estado_usuarios']); ?></td>
                            <td>
                                <a href="editar_usuario.php?id=<?php echo $row['id_usuarios']; ?>" class="btn">Editar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>

<?php mysqli_close($conexion); ?>
