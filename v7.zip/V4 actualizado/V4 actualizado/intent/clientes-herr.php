<?php
session_start();

// Verificar si el usuario está autenticado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$host = '154.38.166.102';
$port = '3306';
$db = 'g1_sgg';
$user = 'fmario';
$password = 'fmario';

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error al conectar con la base de datos: " . $e->getMessage());
}

// Obtener información de los clientes con membresías activas e inactivas
$query = "
    SELECT 
        c.id_clientes,
        u.nombre_completo_usuarios,
        u.correo_usuarios,
        c.fecha_inicio_membresia_clientes,
        c.estado_membresia_clientes,
        m.tipo_membresias,
        m.duracion_membresias,
        DATE_ADD(c.fecha_inicio_membresia_clientes, INTERVAL m.duracion_membresias DAY) AS fecha_fin_membresia,
        p.id_pagos
    FROM clientes c
    INNER JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios
    LEFT JOIN pagos p ON c.id_clientes = p.cliente_id_pagos
    LEFT JOIN membresias m ON p.membresia_id_pagos = m.id_membresias
    ORDER BY c.id_clientes;
";

$stmt = $pdo->query($query);
$clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener todos los tipos de membresía disponibles
$membresias_query = "SELECT id_membresias, tipo_membresias FROM membresias";
$stmt_membresias = $pdo->query($membresias_query);
$membresias = $stmt_membresias->fetchAll(PDO::FETCH_ASSOC);

// Actualizar el estado de la membresía o tipo de membresía si el formulario es enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_cliente = $_POST['id_cliente'];
    $nuevo_estado = $_POST['estado_membresia_clientes'];
    $nuevo_tipo_membresia = $_POST['tipo_membresia'];

    // Actualizar el estado de la membresía en la tabla de clientes
    $update_query = "
        UPDATE clientes 
        SET estado_membresia_clientes = :nuevo_estado
        WHERE id_clientes = :id_cliente
    ";

    $stmt_update = $pdo->prepare($update_query);
    $stmt_update->execute([
        ':nuevo_estado' => $nuevo_estado,
        ':id_cliente' => $id_cliente
    ]);

    // Actualizar el tipo de membresía en la tabla de pagos
    $update_pago_query = "
        UPDATE pagos
        SET membresia_id_pagos = :nuevo_tipo_membresia
        WHERE cliente_id_pagos = :id_cliente
    ";

    $stmt_update_pago = $pdo->prepare($update_pago_query);
    $stmt_update_pago->execute([
        ':nuevo_tipo_membresia' => $nuevo_tipo_membresia,
        ':id_cliente' => $id_cliente
    ]);

    // Redirigir para evitar reenvío de formulario
    header("Location: clientes-herr.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clientes</title>
    <link rel="stylesheet" href="style/style_clienteadmin.css">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        form { display: inline; }
    </style>

</head>
<body>
    <h1>Clientes</h1>
    <a href="javascript:history.back()" class="btn-volver">Volver Atrás</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Fecha Inicio Membresía</th>
                <th>Estado Membresía</th>
                <th>Tipo de Membresía</th>
                <th>Fecha Fin Membresía</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($clientes as $cliente): ?>
                <tr>
                    <td><?= htmlspecialchars($cliente['id_clientes']) ?></td>
                    <td><?= htmlspecialchars($cliente['nombre_completo_usuarios']) ?></td>
                    <td><?= htmlspecialchars($cliente['correo_usuarios']) ?></td>
                    <td><?= htmlspecialchars($cliente['fecha_inicio_membresia_clientes']) ?></td>
                    <td><?= htmlspecialchars($cliente['estado_membresia_clientes']) ?></td>
                    <td><?= htmlspecialchars($cliente['tipo_membresias'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($cliente['fecha_fin_membresia'] ?? 'N/A') ?></td>
                    <td>
                        <!-- Formulario para editar estado de membresía y tipo de membresía -->
                        <form method="POST" action="clientes-herr.php">
                            <input type="hidden" name="id_cliente" value="<?= $cliente['id_clientes'] ?>">
                            <select name="estado_membresia_clientes">
                                <option value="activa" <?= $cliente['estado_membresia_clientes'] == 'activa' ? 'selected' : '' ?>>Activa</option>
                                <option value="inactiva" <?= $cliente['estado_membresia_clientes'] == 'inactiva' ? 'selected' : '' ?>>Inactiva</option>
                            </select>
                            <select name="tipo_membresia">
                                <?php foreach ($membresias as $membresia): ?>
                                    <option value="<?= $membresia['id_membresias'] ?>" <?= $cliente['tipo_membresias'] == $membresia['tipo_membresias'] ? 'selected' : '' ?>>
                                        <?= $membresia['tipo_membresias'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit">Actualizar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
