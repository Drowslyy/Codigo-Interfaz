<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verificar si se ha recibido el parámetro de edición
if (isset($_GET['editar_id'])) {
    $editar_id = $_GET['editar_id'];

    // Obtener los datos del pago para editar
    $sql = "SELECT p.*, m.tipo_membresias, m.precio_membresias, m.duracion_membresias, m.beneficios_membresias 
            FROM pagos p
            JOIN membresias m ON p.membresia_id_pagos = m.id_membresias
            WHERE p.id_pagos = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $editar_id);
    mysqli_stmt_execute($stmt);
    $resultado = mysqli_stmt_get_result($stmt);

    if ($resultado) {
        $row = mysqli_fetch_assoc($resultado);
    } else {
        die("Error al obtener los datos del pago.");
    }
}

// Actualizar los datos del pago
if (isset($_POST['actualizar_pago'])) {
    $id_pago = $_POST['id_pago'];
    $precio = $_POST['precio'];
    $duracion = $_POST['duracion'];
    $beneficios = $_POST['beneficios'];

    // Actualizar el pago en la base de datos
    $sql_update = "UPDATE membresias SET precio_membresias = ?, duracion_membresias = ?, beneficios_membresias = ? WHERE id_membresias = ?";
    $stmt_update = mysqli_prepare($conexion, $sql_update);
    mysqli_stmt_bind_param($stmt_update, 'disi', $precio, $duracion, $beneficios, $row['membresia_id_pagos']);
    $resultado_update = mysqli_stmt_execute($stmt_update);

    if ($resultado_update) {
        header("Location: pagos-herr.php");
        exit();
    } else {
        echo "Error al actualizar el pago.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Pago</title>
    <link rel="stylesheet" href="style/style_editarpagos.css">
</head>
<body>

    <main>
    <section class="container">
        <button class="regresar" onclick="window.location.href='historial_pagos_recepcionista.php'">Regresar</button>
        <h1>Editar Pago</h1>
        <form method="POST">
            <input type="hidden" name="id_pago" value="<?php echo htmlspecialchars($row['id_pagos']); ?>">

            <label for="cliente_id">ID Cliente:</label>
            <input type="text" name="cliente_id" id="cliente_id" value="<?php echo htmlspecialchars($row['cliente_id_pagos']); ?>" disabled><br>

            <label for="membresia_id">ID Membresía:</label>
            <input type="text" name="membresia_id" id="membresia_id" value="<?php echo htmlspecialchars($row['membresia_id_pagos']); ?>" disabled><br>

            <label for="tipo_membresia">Tipo Membresía:</label>
            <input type="text" name="tipo_membresia" id="tipo_membresia" value="<?php echo htmlspecialchars($row['tipo_membresias']); ?>" disabled><br>

            <label for="precio">Precio:</label>
            <input type="number" name="precio" id="precio" value="<?php echo htmlspecialchars($row['precio_membresias']); ?>" required><br>

            <label for="duracion">Duración:</label>
            <input type="number" name="duracion" id="duracion" value="<?php echo htmlspecialchars($row['duracion_membresias']); ?>" required><br>

            <label for="beneficios">Beneficios:</label>
            <textarea name="beneficios" id="beneficios" required><?php echo htmlspecialchars($row['beneficios_membresias']); ?></textarea><br>

            <button type="submit" name="actualizar_pago">Actualizar Pago</button>
        </form>
    </section>

    </main>
</body>
</html>

<?php mysqli_close($conexion); ?>
