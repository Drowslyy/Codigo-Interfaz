<?php 
session_start();

// Verificar si el administrador está logueado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Conectar con la base de datos
$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Procesar la adición de un nuevo recepcionista
if (isset($_POST['guardar'])) {
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];
    $fecha_contratacion = $_POST['fecha_contratacion'];
    $salario = $_POST['salario'];
    $estado = $_POST['estado'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];

    // Manejar la foto de perfil
    $foto_perfil = '';
    if (isset($_FILES['foto_perfil']) && $_FILES['foto_perfil']['error'] == 0) {
        $foto_perfil = $_FILES['foto_perfil']['name'];
        $upload_dir = 'uploads/';
        move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $upload_dir . $foto_perfil);
    }

    // Insertar el nuevo recepcionista en la base de datos
    $sql = "INSERT INTO recepcionistas (nombre_completo_recepcionistas, correo_recepcionistas, contraseña_recepcionistas, fecha_contratacion_recepcionistas, salario_recepcionistas, estado_recepcionistas, telefono_recepcionistas, direccion_recepcionistas, foto_perfil_recepcionistas) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sssssssss", $nombre_completo, $correo, $contraseña, $fecha_contratacion, $salario, $estado, $telefono, $direccion, $foto_perfil);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<p>Recepcionista añadido correctamente.</p>";
    } else {
        echo "<p>Error al añadir el recepcionista: " . mysqli_error($conexion) . "</p>";
    }
    mysqli_stmt_close($stmt);
}

// Cerrar la conexión
mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Recepcionista</title>
    <link rel="stylesheet" href="style/style_añadirrecepcion.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<body>


    <main>
        <form action="añadir_recepcionista.php" method="POST" enctype="multipart/form-data">
            <label for="nombre_completo">Nombre Completo:</label>
            <input type="text" name="nombre_completo" required><br><br>

            <label for="correo">Correo Electrónico:</label>
            <input type="email" name="correo" required><br><br>

            <label for="contraseña">Contraseña:</label>
            <input type="password" name="contraseña" required><br><br>

            <label for="fecha_contratacion">Fecha de Contratación:</label>
            <input type="date" name="fecha_contratacion" required><br><br>

            <label for="salario">Salario:</label>
            <input type="number" name="salario" step="0.01" required><br><br>

            <label for="estado">Estado:</label>
            <input type="text" name="estado" required><br><br>

            <label for="telefono">Teléfono:</label>
            <input type="text" name="telefono" required><br><br>

            <label for="direccion">Dirección:</label>
            <input type="text" name="direccion" required><br><br>

            <label for="foto_perfil">Foto de Perfil:</label>
            <input type="file" name="foto_perfil" accept="image/png, image/jpeg"><br><br>

            <button type="submit" name="guardar">Guardar</button>
        </form>

        <div class="button-group">
                <a href="admin_dashboard.php" class= "btn" >Regresar</a>
            </div>

    </main>
</body>
</html>
