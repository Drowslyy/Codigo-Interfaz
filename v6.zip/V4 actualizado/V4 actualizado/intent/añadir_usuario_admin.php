<?php
session_start();

// Verificar si el administrador está autenticado
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Conectar con la base de datos
$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Procesar el formulario de envío
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $estado = $_POST['estado'];
    $rol = $_POST['rol'];
    $contraseña = $_POST['contraseña']; // Contraseña sin cifrar

    // Subir foto de perfil
    $foto_nombre = null;
    if (!empty($_FILES['foto_perfil']['name'])) {
        $foto_nombre = basename($_FILES['foto_perfil']['name']);
        $foto_tmp = $_FILES['foto_perfil']['tmp_name'];
        $directorio_subida = "uploads/";

        // Mover archivo al directorio
        if (!move_uploaded_file($foto_tmp, $directorio_subida . $foto_nombre)) {
            die("Error al subir la foto de perfil.");
        }
    }

    // Insertar en la base de datos
    $sql = "INSERT INTO usuarios (nombre_completo_usuarios, correo_usuarios, telefono_usuarios, estado_usuarios, rol_usuarios, contraseña_usuarios, foto_perfil_usuarios, fecha_registro_usuarios) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "sssssss", $nombre_completo, $correo, $telefono, $estado, $rol, $contraseña, $foto_nombre);

    if (mysqli_stmt_execute($stmt)) {
        // Redirigir a la gestión de clientes después de añadir
        header("Location: clientes-herr.php");
        exit();
    } else {
        echo "<p>Error al añadir el usuario: " . mysqli_error($conexion) . "</p>";
    }

    mysqli_stmt_close($stmt);
}

mysqli_close($conexion);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Usuario</title>
    <link rel="stylesheet" href="style/style_clienteadmin.css">
</head>
<body>
    <main>
        <section class="container">
            <h1>Añadir Nuevo Usuario</h1>
            <form action="añadir_usuario_admin.php" method="POST" enctype="multipart/form-data">
                <label for="foto_perfil">Foto de Perfil:</label>
                <input type="file" id="foto_perfil" name="foto_perfil" accept="image/png, image/jpeg"><br><br>

                <label for="nombre_completo">Nombre Completo:</label>
                <input type="text" id="nombre_completo" name="nombre_completo" required><br><br>

                <label for="correo">Correo Electrónico:</label>
                <input type="email" id="correo" name="correo" required><br><br>

                <label for="telefono">Teléfono:</label>
                <input type="text" id="telefono" name="telefono" required><br><br>

                <label for="estado">Estado:</label>
                <select id="estado" name="estado" required>
                    <option value="activo">Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select><br><br>

                <label for="rol">Rol:</label>
                <select id="rol" name="rol" required>
                    <option value="usuario">Usuario</option>
                    <option value="administrador">Administrador</option>
                </select><br><br>

                <label for="contraseña">Contraseña:</label>
                <input type="text" id="contraseña" name="contraseña" required><br><br> <!-- Cambiado a texto plano -->

                <button type="submit" class="btn">Añadir Usuario</button>
            </form>
            <a href="clientes-herr.php" class="btn">Regresar a la Gestión de Clientes</a>
        </section>
    </main>
</body>
</html>
