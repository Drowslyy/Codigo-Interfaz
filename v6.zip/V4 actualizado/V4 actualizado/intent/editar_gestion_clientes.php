<?php
session_start();

// Verificar si el usuario está logueado como administrador
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Conexión a la base de datos
$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

// Verificar conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Verificar si se ha pasado el id del usuario
if (isset($_GET['id_usuario'])) {
    $id_usuario = $_GET['id_usuario'];

    // Obtener los datos del usuario
    $sql_usuario = "SELECT * FROM usuarios WHERE id_usuarios = ?";
    if ($stmt = mysqli_prepare($conexion, $sql_usuario)) {
        mysqli_stmt_bind_param($stmt, "i", $id_usuario);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $id, $nombre_completo, $correo, $contraseña, $fecha_registro, $rol, $estado, $telefono, $direccion, $fecha_nacimiento, $foto_perfil);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
    }

    // Obtener los datos de la membresía del cliente
    $sql_membresia = "SELECT * FROM clientes WHERE usuario_id_clientes = ?";
    if ($stmt_membresia = mysqli_prepare($conexion, $sql_membresia)) {
        mysqli_stmt_bind_param($stmt_membresia, "i", $id_usuario);
        mysqli_stmt_execute($stmt_membresia);
        mysqli_stmt_bind_result($stmt_membresia, $id_cliente, $usuario_id, $fecha_inicio, $estado_membresia);
        mysqli_stmt_fetch($stmt_membresia);
        mysqli_stmt_close($stmt_membresia);
    }
}

// Procesar la actualización si el formulario es enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los valores del formulario
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $estado_usuario = $_POST['estado_usuario'];
    $estado_membresia = $_POST['estado_membresia'];
    $fecha_inicio_membresia = $_POST['fecha_inicio_membresia'];
    $id_membresia = $_POST['id_membresia'];

    // Actualizar los datos del usuario
    $sql_update_usuario = "UPDATE usuarios SET nombre_completo_usuarios = ?, correo_usuarios = ?, telefono_usuarios = ?, direccion_usuarios = ?, fecha_nacimiento_usuarios = ?, estado_usuarios = ? WHERE id_usuarios = ?";
    if ($stmt = mysqli_prepare($conexion, $sql_update_usuario)) {
        mysqli_stmt_bind_param($stmt, "ssssssi", $nombre_completo, $correo, $telefono, $direccion, $fecha_nacimiento, $estado_usuario, $id_usuario);
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo "Datos del usuario actualizados correctamente.<br>";
        } else {
            echo "No se actualizó ningún dato del usuario.<br>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error en la actualización de datos del usuario: " . mysqli_error($conexion);
    }

    // Actualizar los datos de la membresía
    $sql_update_membresia = "UPDATE clientes SET estado_membresia_clientes = ?, fecha_inicio_membresia_clientes = ?, usuario_id_clientes = ? WHERE id_clientes = ?";
    if ($stmt = mysqli_prepare($conexion, $sql_update_membresia)) {
        mysqli_stmt_bind_param($stmt, "ssii", $estado_membresia, $fecha_inicio_membresia, $id_usuario, $id_cliente);
        mysqli_stmt_execute($stmt);
        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo "Datos de la membresía actualizados correctamente.<br>";
        } else {
            echo "No se actualizó ningún dato de la membresía.<br>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error en la actualización de la membresía: " . mysqli_error($conexion);
    }

    // Redirigir después de la actualización
    header("Location: gestion_clientes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style_clienteadmin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Editar Cliente</title>
</head>
<body>
    <h2>Editar Cliente</h2>

    <form method="POST" action="editar_gestion_clientes.php?id_usuario=<?php echo $id_usuario; ?>">
        <label for="nombre_completo">Nombre Completo:</label>
        <input type="text" name="nombre_completo" value="<?php echo isset($nombre_completo) ? $nombre_completo : ''; ?>" required>

        <label for="correo">Correo:</label>
        <input type="email" name="correo" value="<?php echo isset($correo) ? $correo : ''; ?>" required>

        <label for="telefono">Teléfono:</label>
        <input type="text" name="telefono" value="<?php echo isset($telefono) ? $telefono : ''; ?>">

        <label for="direccion">Dirección:</label>
        <textarea name="direccion"><?php echo isset($direccion) ? $direccion : ''; ?></textarea>

        <label for="fecha_nacimiento">Fecha de Nacimiento:</label>
        <input type="date" name="fecha_nacimiento" value="<?php echo isset($fecha_nacimiento) ? $fecha_nacimiento : ''; ?>">

        <label for="estado_usuario">Estado:</label>
        <select name="estado_usuario">
            <option value="activo" <?php echo isset($estado) && $estado == 'activo' ? 'selected' : ''; ?>>Activo</option>
            <option value="inactivo" <?php echo isset($estado) && $estado == 'inactivo' ? 'selected' : ''; ?>>Inactivo</option>
        </select>

        <h3>Membresía</h3>
        <label for="estado_membresia">Estado Membresía:</label>
        <select name="estado_membresia">
            <option value="activa" <?php echo isset($estado_membresia) && $estado_membresia == 'activa' ? 'selected' : ''; ?>>Activa</option>
            <option value="inactiva" <?php echo isset($estado_membresia) && $estado_membresia == 'inactiva' ? 'selected' : ''; ?>>Inactiva</option>
        </select>

        <label for="fecha_inicio_membresia">Fecha Inicio Membresía:</label>
        <input type="date" name="fecha_inicio_membresia" value="<?php echo isset($fecha_inicio) ? $fecha_inicio : ''; ?>">

        <label for="id_membresia">Membresía:</label>
        <select name="id_membresia">
            <option value="1" <?php echo isset($id_membresia) && $id_membresia == 1 ? 'selected' : ''; ?>>Mensual</option>
            <option value="2" <?php echo isset($id_membresia) && $id_membresia == 2 ? 'selected' : ''; ?>>Anual</option>
            <option value="3" <?php echo isset($id_membresia) && $id_membresia == 3 ? 'selected' : ''; ?>>Diaria</option>
        </select>

        <button type="submit">Actualizar</button>
    </form>
</body>
</html>
