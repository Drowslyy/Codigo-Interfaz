<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Consulta para obtener usuarios sin membresía
$query = "SELECT * FROM usuarios 
          WHERE id_usuarios NOT IN (
              SELECT cliente_id_pagos 
              FROM pagos
          )";
$resultado = mysqli_query($conexion, $query);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios</title>
</head>
<body>
    <h1>Usuarios Sin Membresía</h1>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre Completo</th>
                <th>Correo</th>
                <th>Teléfono</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($resultado)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id_usuarios']); ?></td>
                    <td><?php echo htmlspecialchars($row['nombre_completo_usuarios']); ?></td>
                    <td><?php echo htmlspecialchars($row['correo_usuarios']); ?></td>
                    <td><?php echo htmlspecialchars($row['telefono_usuarios']); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
<?php mysqli_close($conexion); ?>
