<?php
$servername = "154.38.166.102:3306";
$username = "fmario";  // Cambia si es necesario
$password = "fmario";      // Cambia si es necesario
$dbname = "g1_sgg";  // Cambia si es necesario

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
