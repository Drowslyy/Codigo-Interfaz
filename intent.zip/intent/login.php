<?php
session_start();
include('includes/connection_db.php'); // Conexión a la base de datos

if (isset($_POST['correo']) && isset($_POST['contraseña']) && isset($_POST['rol'])) {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];
    $rol = $_POST['rol']; // Obtiene el rol seleccionado (Usuario o Administrador)

    if ($rol == 'administrador') {
        // Si el rol es administrador, consultar en la tabla de administradores
        $sql_admin = "SELECT * FROM administradores WHERE correo_administradores = ?";
        $stmt_admin = $conn->prepare($sql_admin);
        $stmt_admin->bind_param('s', $correo);
        $stmt_admin->execute();
        $result_admin = $stmt_admin->get_result();

        if ($result_admin->num_rows > 0) {
            $row_admin = $result_admin->fetch_assoc();

            // Verificar la contraseña
            if ($contraseña == $row_admin['contraseña_administradores']) {
                // Guardar la sesión
                $_SESSION['admin_id'] = $row_admin['id_administradores'];
                $_SESSION['nombre_completo_admin'] = $row_admin['nombre_completo_administradores'];
                header('Location: index.php'); // Redirigir a index.php
                exit();
            } else {
                echo "Contraseña incorrecta para el administrador.";
            }
        } else {
            echo "No se encontró el administrador con ese correo.";
        }
    } else {
        // Si el rol es usuario, consultar en la tabla de usuarios
        $sql_usuario = "SELECT * FROM usuarios WHERE correo_usuarios = ?";
        $stmt_usuario = $conn->prepare($sql_usuario);
        $stmt_usuario->bind_param('s', $correo);
        $stmt_usuario->execute();
        $result_usuario = $stmt_usuario->get_result();

        if ($result_usuario->num_rows > 0) {
            $row_usuario = $result_usuario->fetch_assoc();

            // Verificar la contraseña
            if ($contraseña == $row_usuario['contraseña_usuarios']) {
                // Guardar la sesión
                $_SESSION['usuario_id'] = $row_usuario['id_usuarios'];
                $_SESSION['nombre_completo'] = $row_usuario['nombre_completo_usuarios'];
                header('Location: index.php'); // Redirigir a index.php
                exit();
            } else {
                echo "Contraseña incorrecta para el usuario.";
            }
        } else {
            echo "No se encontró el usuario con ese correo.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>

    <!-- Vincula el archivo CSS externo -->
    <link rel="stylesheet" href="style.css">
    
    <!-- Vincula Font Awesome para los iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <div class="formulario">
        <form method="POST" action="">
            <h2>Iniciar sesión</h2>

            <!-- Selector de rol -->
            <div class="input-container">
                <i class="fas fa-user"></i>
                <select name="rol" required>
                    <option value="usuario">Usuario</option>
                    <option value="administrador">Administrador</option>
                </select>
            </div>

            <!-- Campo de correo -->
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="correo" placeholder="Correo electrónico" required>
            </div>

            <!-- Campo de contraseña -->
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="contraseña" placeholder="Contraseña" required>
            </div>

            <!-- Botón de iniciar sesión -->
            <button class="btn" type="submit">Iniciar sesión</button>

            <!-- Enlace para registrarse -->
            <p class="registro-link">¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a></p>

            <!-- Mensaje de error -->
            <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>
        </form>
    </div>

</body>
</html>
