<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Cambia el nombre de la clave de sesión para que coincida con la que guardaste en login.php
echo "Bienvenido, " . $_SESSION['nombre_completo_admin'] . " (Administrador)";
?>

<!-- Aquí iría el contenido del panel de administración -->
<a href="logout.php">Cerrar sesión</a>
