<?php
// Conexión a la base de datos
include('includes/connection_db.php');

if (isset($_POST['nombre_completo']) && isset($_POST['correo_registro']) && isset($_POST['contraseña_registro'])) {
    // Obtener los datos del formulario
    $nombre_completo = $_POST['nombre_completo'];
    $correo_registro = $_POST['correo_registro'];
    $contraseña_registro = $_POST['contraseña_registro'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    
    // Subir la foto de perfil
    $foto_perfil = $_FILES['foto_perfil']['name'];
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($foto_perfil);
    move_uploaded_file($_FILES['foto_perfil']['tmp_name'], $target_file);

    // Verificar si el correo ya está registrado
    $sql_check = "SELECT * FROM usuarios WHERE correo_usuarios = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param('s', $correo_registro);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        echo "El correo electrónico ya está registrado.";
    } else {
        // Registrar al nuevo usuario
        $sql_insert = "INSERT INTO usuarios (nombre_completo_usuarios, correo_usuarios, contraseña_usuarios, telefono_usuarios, direccion_usuarios, foto_perfil_usuarios, rol_usuarios, fecha_registro_usuarios) 
        VALUES (?, ?, ?, ?, ?, ?, 'usuario', NOW())";
        $stmt_insert = $conn->prepare($sql_insert);
        $stmt_insert->bind_param('ssssss', $nombre_completo, $correo_registro, $contraseña_registro, $telefono, $direccion, $foto_perfil);

        if ($stmt_insert->execute()) {
            echo "Usuario registrado exitosamente.";
        } else {
            echo "Error al registrar el usuario.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Usuario</title>
    <!-- Vincula el archivo CSS externo -->
    <link rel="stylesheet" href="style.css">
    <!-- Vincula Font Awesome para los iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>

    <!-- Imagen del gimnasio -->
    <header class="header">
        <!-- Logo del gimnasio, ubicado encima del formulario -->
        <div class="logo-gym-container">
            <a href="index.php" class="logo">GYM</a>
        </div>
    </header>

    <!-- Contenedor del formulario -->
    <div class="formulario">
        <form method="POST" action="" enctype="multipart/form-data">
            <h2>Registrar Usuario</h2>

            <!-- Campo Nombre completo con icono -->
            <div class="input-container">
                <i class="fas fa-user"></i>
                <input type="text" name="nombre_completo" placeholder="Nombre completo" required>
            </div>

            <!-- Campo Correo electrónico con icono -->
            <div class="input-container">
                <i class="fas fa-envelope"></i>
                <input type="email" name="correo_registro" placeholder="Correo electrónico" required>
            </div>

            <!-- Campo Contraseña con icono -->
            <div class="input-container">
                <i class="fas fa-lock"></i>
                <input type="password" name="contraseña_registro" placeholder="Contraseña" required>
            </div>

            <!-- Campo Teléfono con icono -->
            <div class="input-container">
                <i class="fas fa-phone"></i>
                <input type="text" name="telefono" placeholder="Teléfono" required>
            </div>

            <!-- Campo Dirección con icono -->
            <div class="input-container">
                <i class="fas fa-map-marker-alt"></i>
                <input type="text" name="direccion" placeholder="Dirección" required>
            </div>

            <!-- Campo Foto de perfil -->
            <div class="input-container">
                <i class="fas fa-image"></i>
                <input type="file" name="foto_perfil" accept="image/*">
            </div>

            <!-- Botón de registro -->
            <button type="submit">Registrar</button>

            <!-- Enlace para volver al login -->
            <div class="volver-login">
                <p>¿Tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
            </div>

        </form>
    </div>

</body>
</html>
