<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Estilos del cuadro de bienvenida */
        .bienvenida {
            padding: 30px;
            background-color: #fafafa;
            border: 1px solid #ccc;
            max-width: 400px;
            text-align: center;
            font-size: 18px;
            font-family: Arial, sans-serif;
            color: #333;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        
        /* Estilos del menú desplegable */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fafafa;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            setTimeout(function() {
                var mensaje = document.getElementById("mensajeBienvenida");
                if (mensaje) {
                    mensaje.style.display = "none";
                }
            }, 3000); // 3000 ms = 3 segundos
        });
    </script>
</head>
<body>
    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">GYM</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="ImageGimnasio/menu.png" class="menu-icon" alt="menu">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="#"> Inicio</a></li>
                    <li><a href="#"> Nosotros</a></li>
                    <li><a href="#"> Servicios</a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0)">Herramientas</a>
                        <div class="dropdown-content">
                            <a href="recepcion-herr.php">Recepción</a>
                            <a href="clientes-herr.php">Clientes</a>
                            <a href="pagos-herr.php">Pagos</a>
                            <a href="#">Actividades</a>
                        </div>
                    </li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>

        <div class="header-content container">
            <div class="header-txt">
                <h1>Central Gym</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium earum nostrum, unde eveniet et ipsum, laudantium, fuga quae soluta 
                    minima veniam ullam. Cupiditate veniam nemo esse cumque sequi minima ipsam?
                </p>
                <a href="#" class="btn-1">informacion</a>
            </div>
            <div class="header-img">
                <img src="ImageGimnasio/gym.jpg" alt="">
            </div>


                
            
        </div>



    </header>
    
    <div id="mensajeBienvenida" class="bienvenida">
        <?php
        echo "Bienvenido " . $_SESSION['nombre_completo_admin'] . "\n(Administrador)";
        ?>
    </div>

