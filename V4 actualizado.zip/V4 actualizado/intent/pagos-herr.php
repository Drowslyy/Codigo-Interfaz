<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Consulta para obtener todos los pagos junto con la información de las membresías
$sql = "
    SELECT p.*, m.tipo_membresias, m.precio_membresias, m.duracion_membresias, m.beneficios_membresias 
    FROM pagos p
    JOIN membresias m ON p.membresia_id_pagos = m.id_membresias";
$resultado = mysqli_query($conexion, $sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Error en la consulta SQL: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Pagos</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Estilos del menú desplegable */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fafafa;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">GYM</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="ImageGimnasio/menu.png" class="menu-icon" alt="menu">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="admin_dashboard.php">Inicio</a></li>
                    <li><a href="#">Nosotros</a></li>
                    <li><a href="#">Servicios</a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0)">Herramientas</a>
                        <div class="dropdown-content">
                            <a href="recepcion-herr.php">Recepción</a>
                            <a href="clientes-herr.php">Clientes</a>
                            <a href="pagos-herr.php">Pagos</a>
                            <a href="#">Actividades</a>
                        </div>
                    </li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h1>Gestión de Pagos</h1>

            <div class="button-group">
                <a href="añadir_pago.php" class="btn">Añadir Pago</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ID Cliente</th>
                        <th>ID Membresía</th>
                        <th>Tipo Membresía</th>
                        <th>Precio</th>
                        <th>Duración</th>
                        <th>Beneficios</th>
                        <th>Fecha de Pago</th>
                        <th>Tiempo Restante</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Procesar los resultados de la consulta
                    while ($row = mysqli_fetch_assoc($resultado)) {
                        // Calcular la fecha de vencimiento de la membresía
                        $fecha_pago = new DateTime($row['fecha_pago_pagos']);
                        $duracion = $row['duracion_membresias']; // Duración en días
                        $fecha_vencimiento = $fecha_pago->modify("+$duracion days");
                        $fecha_vencimiento_str = $fecha_vencimiento->format('Y-m-d H:i:s'); // Para enviar a JavaScript
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['id_pagos']); ?></td>
                            <td><?php echo htmlspecialchars($row['cliente_id_pagos']); ?></td>
                            <td><?php echo htmlspecialchars($row['membresia_id_pagos']); ?></td>
                            <td><?php echo htmlspecialchars($row['tipo_membresias']); ?></td>
                            <td><?php echo htmlspecialchars($row['precio_membresias']); ?></td>
                            <td><?php echo htmlspecialchars($row['duracion_membresias']); ?> días</td>
                            <td><?php echo htmlspecialchars($row['beneficios_membresias']); ?></td>
                            <td><?php echo htmlspecialchars($row['fecha_pago_pagos']); ?></td>
                            <td id="tiempo_restante_<?php echo $row['id_pagos']; ?>" data-fecha-vencimiento="<?php echo $fecha_vencimiento_str; ?>">
                                Cargando...
                            </td>
                            <td>
                                <a href="editar_pago.php?editar_id=<?php echo $row['id_pagos']; ?>" class="btn">Editar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>

    <script>
        //Calcular el tiempo restante en días, horas, minutos y segundos
        function actualizarCuentaRegresiva() {
            const elementos = document.querySelectorAll('td[id^="tiempo_restante_"]');

            elementos.forEach(function(elemento) {
                // Obtener la fecha de vencimiento desde el atributo "data-fecha-vencimiento"
                const fechaVencimiento = new Date(elemento.getAttribute('data-fecha-vencimiento'));
                const ahora = new Date();

                // Calcular la diferencia en milisegundos
                const diferencia = fechaVencimiento - ahora;

                if (diferencia > 0) {
                    // Calcular días, horas, minutos y segundos
                    const dias = Math.floor(diferencia / (1000 * 60 * 60 * 24));
                    const horas = Math.floor((diferencia % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const minutos = Math.floor((diferencia % (1000 * 60 * 60)) / (1000 * 60));
                    const segundos = Math.floor((diferencia % (1000 * 60)) / 1000);

                    // Mostrar la cuenta atrás en el formato deseado (sin milisegundos)
                    elemento.innerHTML = `${dias}d ${horas}h ${minutos}m ${segundos}s`;
                } else {
                    // Si el tiempo ha llegado a 0, mostrar "Vencido"
                    elemento.innerHTML = "Vencido";
                }
            });
        }

        // Actualizar la cuenta regresiva cada 1 segundo
        setInterval(actualizarCuentaRegresiva, 1000);
    </script>
</body>
</html>

<?php mysqli_close($conexion); ?>
        