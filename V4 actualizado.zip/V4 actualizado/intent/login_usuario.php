<?php
session_start();
include('includes/connection_db.php'); // Conexión a la base de datos

if (isset($_POST['correo']) && isset($_POST['contraseña'])) {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Consultar en la tabla de usuarios
    $sql_usuario = "SELECT * FROM usuarios WHERE correo_usuarios = ?"; // Cambiar 'correo' por 'correo_usuarios'
    $stmt_usuario = $conn->prepare($sql_usuario);
    $stmt_usuario->bind_param('s', $correo);
    $stmt_usuario->execute();
    $result_usuario = $stmt_usuario->get_result();

    if ($result_usuario->num_rows > 0) {
        $row_usuario = $result_usuario->fetch_assoc();

        // Verificar la contraseña sin cifrar (si no estás usando password_hash)
        if ($contraseña == $row_usuario['contraseña_usuarios']) { // Cambiar 'contraseña' por 'contraseña_usuarios'
            // Guardar la sesión
            $_SESSION['usuario_id'] = $row_usuario['id_usuarios']; // Cambiar 'id' por 'id_usuarios'
            $_SESSION['nombre_completo'] = $row_usuario['nombre_completo_usuarios']; // Cambiar 'nombre_completo' por 'nombre_completo_usuarios'
            header('Location: index.php');
            exit();
        } else {
            echo "Contraseña incorrecta para el usuario.";
        }
    } else {
        echo "No se encontró el usuario con ese correo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>

    <h2>Iniciar sesión</h2>

    <?php if (isset($error)) { echo "<p style='color:red;'>$error</p>"; } ?>

    <form method="POST" action="">
        <label for="correo">Correo:</label>
        <input type="email" name="correo" required><br><br>

        <label for="contraseña">Contraseña:</label>
        <input type="password" name="contraseña" required><br><br>

        <button type="submit">Iniciar sesión</button>
    </form>

</body>
</html>
