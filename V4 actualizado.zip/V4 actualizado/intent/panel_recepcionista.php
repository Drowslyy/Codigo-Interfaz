<?php
session_start();

// Verificar si el recepcionista está logueado
if (!isset($_SESSION['recepcionista_id'])) {
    header("Location: login.php");
    exit();
}

// Conectar con la base de datos
$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Recuperar el ID del recepcionista logueado
$id_recepcionista = $_SESSION['recepcionista_id'];

// Verificar si el formulario ha sido enviado para actualizar la contraseña
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['password'])) {
    $nueva_contraseña = $_POST['password'];
    if (!empty($nueva_contraseña)) {
        $nueva_contraseña_encriptada = password_hash($nueva_contraseña, PASSWORD_DEFAULT);
        $sql = "UPDATE recepcionistas SET contraseña_recepcionistas = ? WHERE id_recepcionistas = ?";
        $stmt = mysqli_prepare($conexion, $sql);
        mysqli_stmt_bind_param($stmt, "si", $nueva_contraseña_encriptada, $id_recepcionista);

        if (mysqli_stmt_execute($stmt)) {
            echo "Contraseña actualizada correctamente.";
        } else {
            echo "Error al actualizar la contraseña: " . mysqli_error($conexion);
        }
        mysqli_stmt_close($stmt);
    }
}

// Recuperar la información del recepcionista desde la base de datos
$sql = "SELECT * FROM recepcionistas WHERE id_recepcionistas = ?";
$stmt = mysqli_prepare($conexion, $sql);
mysqli_stmt_bind_param($stmt, "i", $id_recepcionista);
mysqli_stmt_execute($stmt);
$resultado = mysqli_stmt_get_result($stmt);
$recepcionista = mysqli_fetch_assoc($resultado);
mysqli_stmt_close($stmt);

// Procesar búsquedas de pagos, reservas y usuarios
$buscar_pago = isset($_GET['buscar_pago']) ? $_GET['buscar_pago'] : '';
$buscar_reserva = isset($_GET['buscar_reserva']) ? $_GET['buscar_reserva'] : '';
$buscar_usuario = isset($_GET['buscar_usuario']) ? $_GET['buscar_usuario'] : '';

// Consultar pagos con filtro de búsqueda
$consulta_pagos = "SELECT p.id_pagos, u.nombre_completo_usuarios AS nombre_cliente, p.monto_pagos, p.fecha_pago_pagos
                   FROM pagos p
                   LEFT JOIN clientes c ON p.cliente_id_pagos = c.id_clientes
                   LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";

// Aplicar filtro de búsqueda si se ha ingresado un término de búsqueda
if ($buscar_pago) {
    $consulta_pagos .= " WHERE u.nombre_completo_usuarios LIKE '%$buscar_pago%' 
                         OR p.fecha_pago_pagos LIKE '%$buscar_pago%'";
}

$consulta_pagos .= " ORDER BY p.fecha_pago_pagos DESC"; // Ordenar por fecha de pago

$pagos = mysqli_query($conexion, $consulta_pagos);


// Realizar la consulta para obtener las reservas
$consulta_reservas = "SELECT r.id_reservas, u.nombre_completo_usuarios AS nombre_cliente, r.fecha_reserva_reservas
                      FROM reservas r
                      LEFT JOIN clientes c ON r.cliente_id_reservas = c.id_clientes
                      LEFT JOIN usuarios u ON c.usuario_id_clientes = u.id_usuarios";

// Verifica si hay un término de búsqueda
if ($buscar_reserva) {
    $consulta_reservas .= " WHERE u.nombre_completo_usuarios LIKE '%$buscar_reserva%' 
                           OR r.fecha_reserva_reservas LIKE '%$buscar_reserva%'";
}

$consulta_reservas .= " ORDER BY r.fecha_reserva_reservas DESC"; // Ordenar por fecha de reserva

$reservas = mysqli_query($conexion, $consulta_reservas);


// Consultar usuarios (clientes)
$consulta_usuarios = "SELECT * FROM usuarios";
if ($buscar_usuario) {
    $consulta_usuarios .= " WHERE nombre_completo_usuarios LIKE '%$buscar_usuario%' OR correo_usuarios LIKE '%$buscar_usuario%'";
}

$usuarios = mysqli_query($conexion, $consulta_usuarios);

// Cerrar la conexión
mysqli_close($conexion);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Recepcionista - Central Gym</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Estilos CSS básicos */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f9;
            color: #333;
            padding: 20px;
            line-height: 1.6;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }

        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-header h1 {
            font-size: 36px;
            color: #0284C7;
            margin-bottom: 10px;
        }

        .profile-header p {
            font-size: 18px;
            color: #555;
        }

        .profile-info {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.05);
        }

        .profile-info h3 {
            font-size: 24px;
            color: #0284C7;
            margin-bottom: 15px;
        }

        .profile-info p {
            font-size: 16px;
            margin-bottom: 10px;
        }

        .btn {
            display: inline-block;
            background-color: #0284C7;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #0270A1;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 8px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ccc;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #0284C7;
            color: white;
        }

        td a {
            background-color: #0284C7;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }

        td a:hover {
            background-color: #0270A1;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="profile-header">
            <h1>Bienvenido al Panel de Recepcionista</h1>
            <p>Hola, <?php echo htmlspecialchars($recepcionista['nombre_completo_recepcionistas']); ?>.</p>
        </div>

        <div class="profile-info">
            <h3>Información del Perfil</h3>
            <form action="" method="POST">
                <label for="nombre">Nombre Completo:</label>
                <input type="text" name="nombre" id="nombre" value="<?php echo htmlspecialchars($recepcionista['nombre_completo_recepcionistas']); ?>" required><br><br>

                <label for="correo">Correo Electrónico:</label>
                <input type="email" name="correo" id="correo" value="<?php echo htmlspecialchars($recepcionista['correo_recepcionistas']); ?>" required><br><br>

                <label for="password">Nueva Contraseña:</label>
                <input type="password" name="password" id="password"><br><br>

                <button type="submit" class="btn">Actualizar Perfil</button>
            </form>
        </div>

        <!-- Sección: Historial de Pagos -->
        <div class="historial-pagos">
            <h3>Historial de Pagos</h3>
            <form method="GET" action="panel_recepcionista.php">
                <input type="text" name="buscar_pago" placeholder="Buscar por cliente o fecha" value="<?php echo $buscar_pago; ?>">
                <button type="submit">Buscar</button>
            </form>

            <table>
                <thead>
                    <tr>
                        <th>ID Pago</th>
                        <th>Cliente</th>
                        <th>Monto</th>
                        <th>Fecha de Pago</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($pago = mysqli_fetch_assoc($pagos)): ?>
                        <tr>
                            <td><?php echo $pago['id_pagos']; ?></td>
                            <td><?php echo $pago['nombre_cliente']; ?></td>
                            <td><?php echo $pago['monto_pagos']; ?></td>
                            <td><?php echo $pago['fecha_pago_pagos']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>

        </div>

        <!-- Sección: Reservas -->
        <div class="reservas">
            <h3>Reservas</h3>
            <form method="GET" action="panel_recepcionista.php">
                    <input type="text" name="buscar_reserva" placeholder="Buscar por cliente o fecha" value="<?php echo $buscar_reserva; ?>">
                    <button type="submit">Buscar</button>
                </form>

                <table>
                    <thead>
                        <tr>
                            <th>ID Reserva</th>
                            <th>Cliente</th>
                            <th>Fecha</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($reserva = mysqli_fetch_assoc($reservas)): ?>
                            <tr>
                                <td><?php echo $reserva['id_reservas']; ?></td>
                                <td><?php echo $reserva['nombre_cliente']; ?></td>
                                <td><?php echo $reserva['fecha_reserva_reservas']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>

        </div>

        <div class="acciones">
            <a href="logout.php" class="btn">Cerrar sesión</a>
        </div>
    </div>
</body>
</html>
