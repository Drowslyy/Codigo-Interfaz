<?php 
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

$conexion = mysqli_connect("154.38.166.102:3306", "fmario", "fmario", "g1_sgg");

if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Procesar la edición de un usuario
if (isset($_POST['editar'])) {
    $id_usuario = $_POST['id_usuario'];
    $nombre_completo = $_POST['nombre_completo'];
    $correo = $_POST['correo'];
    $telefono = $_POST['telefono'];
    $estado = $_POST['estado'];

    // Actualizar en la base de datos
    $sql = "UPDATE usuarios SET nombre_completo_usuarios = ?, correo_usuarios = ?, telefono_usuarios = ?, estado_usuarios = ? WHERE id_usuarios = ?";
    $stmt = mysqli_prepare($conexion, $sql);
    mysqli_stmt_bind_param($stmt, "ssssi", $nombre_completo, $correo, $telefono, $estado, $id_usuario);

    if (mysqli_stmt_execute($stmt)) {
        echo "<p>Usuario actualizado correctamente.</p>";
    } else {
        echo "<p>Error al actualizar los datos: " . mysqli_error($conexion) . "</p>";
    }
    mysqli_stmt_close($stmt);
}

// Consulta para obtener todos los usuarios
$sql = "SELECT * FROM usuarios";
$resultado = mysqli_query($conexion, $sql);

// Verificar si la consulta fue exitosa
if (!$resultado) {
    die("Error en la consulta SQL: " . mysqli_error($conexion));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Estilos del menú desplegable */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fafafa;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
        }
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .dropdown:hover .dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="menu container">
            <a href="#" class="logo">GYM</a>
            <input type="checkbox" id="menu" />
            <label for="menu">
                <img src="ImageGimnasio/menu.png" class="menu-icon" alt="menu">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="admin_dashboard.php">Inicio</a></li>
                    <li><a href="#">Nosotros</a></li>
                    <li><a href="#">Servicios</a></li>
                    <li class="dropdown">
                        <a href="javascript:void(0)">Herramientas</a>
                        <div class="dropdown-content">
                            <a href="recepcion-herr.php">Recepción</a>
                            <a href="clientes-herr.php">Clientes</a>
                            <a href="pagos-herr.php">Pagos</a>
                            <a href="#">Actividades</a>
                        </div>
                    </li>
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h1>Gestión de Usuarios</h1>

            <!-- Formulario de edición, si se selecciona un usuario -->
            <?php if (isset($_GET['editar_id'])) {
                $id_usuario = $_GET['editar_id'];
                $sql = "SELECT * FROM usuarios WHERE id_usuarios = ?";
                $stmt = mysqli_prepare($conexion, $sql);
                mysqli_stmt_bind_param($stmt, "i", $id_usuario);
                mysqli_stmt_execute($stmt);
                $resultado = mysqli_stmt_get_result($stmt);
                $usuario = mysqli_fetch_assoc($resultado);
                mysqli_stmt_close($stmt);
            ?>
            
                <h2>Editar Usuario</h2>
                <form action="usuarios-herr.php" method="POST">
                    <input type="hidden" name="id_usuario" value="<?php echo $usuario['id_usuarios']; ?>">

                    <label for="foto_perfil">Foto de Perfil:</label>
                    <input type="file" id="foto_perfil" name="foto_perfil" accept="image/png, image/jpeg"><br><br>

                    <label for="nombre_completo">Nombre Completo:</label>
                    <input type="text" id="nombre_completo" name="nombre_completo" value="<?php echo htmlspecialchars($usuario['nombre_completo_usuarios']); ?>" required><br><br>

                    <label for="correo">Correo Electrónico:</label>
                    <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($usuario['correo_usuarios']); ?>" required><br><br>

                    <label for="telefono">Teléfono:</label>
                    <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($usuario['telefono_usuarios']); ?>" required><br><br>

                    <label for="estado">Estado:</label>
                    <input type="text" id="estado" name="estado" value="<?php echo htmlspecialchars($usuario['estado_usuarios']); ?>" required><br><br>

                    <button type="submit" name="editar" class="btn">Guardar Cambios</button>
                </form>
            <?php } ?>

            <div class="button-group">
                <a href="añadir_usuario.php" class="btn">Añadir Usuario</a>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Foto de Perfil</th>
                        <th>ID</th>
                        <th>Nombre Completo</th>
                        <th>Correo</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>Fecha de Registro</th>
                        <th>Rol</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>

                <?php
            // Consulta para obtener los usuarios
        $query = "SELECT * FROM usuarios";
        $resultado = mysqli_query($conexion, $query);

        ?>
                    <?php  while ($row = $resultado->fetch_assoc()) { ?>
                        <tr>
                            <td><img src='uploads/<?php echo htmlspecialchars($row['foto_perfil_usuarios']); ?>' alt='Foto de perfil' class='foto-usuario'></td>
                            <td><?php echo htmlspecialchars($row['id_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['nombre_completo_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['correo_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['telefono_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['estado_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['fecha_registro_usuarios']); ?></td>
                            <td><?php echo htmlspecialchars($row['rol_usuarios']); ?></td>
                            <td>
                                <a href="usuarios-herr.php?editar_id=<?php echo $row['id_usuarios']; ?>" class="btn">Editar</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>

<?php mysqli_close($conexion); ?>
