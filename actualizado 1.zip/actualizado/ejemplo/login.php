<?php
session_start();
include 'includes/db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Consulta para verificar el correo y la contraseña en la tabla de administradores
    $sql_admin = "SELECT id_admin, nombre_admin FROM administradores WHERE correo_admin = ? AND contraseña_admin = ?";
    $stmt_admin = $conn->prepare($sql_admin);
    $stmt_admin->bind_param('ss', $email, $password);
    $stmt_admin->execute();
    $result_admin = $stmt_admin->get_result();
    $admin = $result_admin->fetch_assoc();

    if ($admin) {
        $_SESSION['user_id'] = $admin['id_admin'];
        $_SESSION['role'] = 'admin';
        // Redirigir a la página de administradores
        header('Location: administradores.php');
        exit();
    }

    // Consulta para verificar el correo y la contraseña en la tabla de vendedores
    $sql_vendedor = "SELECT id_vendedor, nombre_vendedor FROM vendedores WHERE email_vendedor = ? AND contraseña_vendedor = ?";
    $stmt_vendedor = $conn->prepare($sql_vendedor);
    $stmt_vendedor->bind_param('ss', $email, $password);
    $stmt_vendedor->execute();
    $result_vendedor = $stmt_vendedor->get_result();
    $vendedor = $result_vendedor->fetch_assoc();

    if ($vendedor) {
        $_SESSION['user_id'] = $vendedor['id_vendedor'];
        $_SESSION['role'] = 'vendedor';
        // Redirigir a la página del vendedor
        header('Location: vendedores.php');
        exit();
    }

    // Consulta para verificar el correo y la contraseña en la tabla de usuarios
    $sql_usuario = "SELECT id, nombre_per_usu FROM usuarios WHERE email_usu = ? AND contraseña_usu = ?";
    $stmt_usuario = $conn->prepare($sql_usuario);
    $stmt_usuario->bind_param('ss', $email, $password);
    $stmt_usuario->execute();
    $result_usuario = $stmt_usuario->get_result();
    $usuario = $result_usuario->fetch_assoc();

    if ($usuario) {
        $_SESSION['user_id'] = $usuario['id'];
        $_SESSION['role'] = 'usuario';
        // Redirigir a la página de usuarios
        header('Location: usuarios.php');
        exit();
    }

    $error_message = "Correo o contraseña incorrectos";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio de Sesión</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .login-container {
            width: 300px;
            padding: 20px;
            background-color: #fff8dc;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container h1 {
            margin-bottom: 20px;
            color: #8b7765;
        }
        .login-container input[type="email"],
        .login-container input[type="password"],
        .login-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        .login-container input[type="email"]:focus,
        .login-container input[type="password"]:focus,
        .login-container input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        .login-container input[type="submit"] {
            background-color: #8b7765;
            color: white;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #654321;
        }
        .login-container .error {
            color: #dc3545;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Inicio de Sesión</h1>
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <input type="password" name="password" placeholder="Contraseña" required>
            <input type="submit" value="Iniciar Sesión">
        </form>
        <?php if (isset($error_message)): ?>
            <div class="error"><?= $error_message ?></div>
        <?php endif; ?>
    </div>
</body>
</html>








