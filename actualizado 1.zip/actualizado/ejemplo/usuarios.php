<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

// Establecer la conexión con la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si el usuario ha iniciado sesión y tiene el rol correcto
if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'usuario') {
    header('Location: login.php');
    exit();
}

// Obtener el ID del usuario y su nombre
$user_id = $_SESSION['user_id'];
$nombre_usuario = "";

// Consulta preparada para obtener el nombre del usuario
$sql_nombre_usuario = "SELECT nombre_usuario FROM usuarios WHERE id = ?";
$stmt_nombre_usuario = $conn->prepare($sql_nombre_usuario);
$stmt_nombre_usuario->bind_param("i", $user_id);
$stmt_nombre_usuario->execute();
$stmt_nombre_usuario->store_result();

// Verificar si se encontró un usuario con el ID proporcionado
if ($stmt_nombre_usuario->num_rows > 0) {
    $stmt_nombre_usuario->bind_result($nombre_usuario);
    $stmt_nombre_usuario->fetch();
} else {
    // Si no se encontró un usuario, redirigir a la página de inicio de sesión
    header('Location: login.php');
    exit();
}

$stmt_nombre_usuario->close();

// Consulta para obtener el ID del subgénero de interés del usuario
$id_interes = 0;
$nombre_subgenero = "";

$sql_id_interes = "SELECT id_subgenero FROM intereses WHERE id_usuario = ?";
$stmt_id_interes = $conn->prepare($sql_id_interes);
$stmt_id_interes->bind_param("i", $user_id);
$stmt_id_interes->execute();
$stmt_id_interes->store_result();

// Verificar si se encontró un subgénero de interés para el usuario
if ($stmt_id_interes->num_rows > 0) {
    $stmt_id_interes->bind_result($id_interes);
    $stmt_id_interes->fetch();

    // Consulta para obtener el nombre del subgénero de interés del usuario
    $sql_nombre_subgenero = "SELECT nombre_interes FROM intereses WHERE id_subgenero = ?";
    $stmt_nombre_subgenero = $conn->prepare($sql_nombre_subgenero);
    $stmt_nombre_subgenero->bind_param("i", $id_interes);
    $stmt_nombre_subgenero->execute();
    $stmt_nombre_subgenero->store_result();

    // Verificar si se encontró el nombre del subgénero de interés
    if ($stmt_nombre_subgenero->num_rows > 0) {
        $stmt_nombre_subgenero->bind_result($nombre_subgenero);
        $stmt_nombre_subgenero->fetch();
    }
}

$stmt_id_interes->close();
$stmt_nombre_subgenero->close();

// Consulta para obtener los libros asociados al subgénero del usuario
$sql_libros = "SELECT * FROM libros WHERE id_subgenero = ? LIMIT 10";
$stmt_libros = $conn->prepare($sql_libros);
$stmt_libros->bind_param("i", $id_interes);
$stmt_libros->execute();
$result_libros = $stmt_libros->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Bienvenido Usuario</title>
    <link rel="stylesheet" href="css/styles.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5dc;
            margin: 0;
            padding: 0;
            color: #333;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #d2b48c;
            color: white;
        }
        header h1 {
            margin: 0;
        }
        .login-button {
            padding: 10px 20px;
            background-color: #8b7765;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .login-button:hover {
            background-color: #654321;
        }
        .container {
            width: 95%;
            max-width: 2000px;
            padding: 45px;
            background-color: #fff8dc;
            border-radius: 100px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin: 60px auto;
            text-align: center;
        }
        h1 {
            color: #8b7765;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            background: #fff8dc;
            padding: 20px;
            border-radius: 100px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .form-group {
            margin: 10px;
            flex: 1;
            min-width: 150px;
        }
        form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        form select,
        form input[type="text"],
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        form input[type="text"]:focus,
        form select:focus,
        form input[type="submit"]:hover {
            border-color: #d2b48c;
            outline: none;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        table th {
            background-color: #d2b48c;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #fff8dc;
        }
        table tr:hover {
            background-color: #f5f5dc;
        }
        .button-container {
            display: flex;
            justify-content: center;
        }
        .button {
            padding: 5px 10px;
            text-decoration: none;
            background-color: #8b7765;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .button:hover {
            background-color: #654321;
        }
        .no-books {
            color: #dc3545;
            font-weight: bold;
            margin-top: 20px;
        }
        .description-button {
            padding: 5px 10px;
            text-decoration: none;
            background-color: #8b7765;
            color: white;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .description-button:hover {
            background-color: #654321;
        }
        .description {
            display: none;
            text-align: left;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <!-- Contenido de la página  -->
    <header>
        <h1>Bienvenido, <?php echo htmlspecialchars($nombre_usuario); ?></h1>
        <nav>
            <ul>
                <li><a href="modify_account.php" class="button">Modificar Datos de la Cuenta</a></li>
                <br>
                <li><a href="search_products.php" class="button">Buscar Productos</a></li>
                <br>
                <li><a href="purchase_history.php" class="button">Historial de Compras</a></li> 
                <br>
                <li><a href="logout.php" class="button">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <h2>Últimos 10 libros subidos pertenecientes al subgénero <?php echo htmlspecialchars($nombre_subgenero); ?></h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Autor</th>
                    <th>Subgénero</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result_libros->num_rows > 0) {
                    while ($row_libro = $result_libros->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row_libro['Titulo']) . "</td>";
                        echo "<td>" . htmlspecialchars($row_libro['autor']) . "</td>";
                        echo "<td>" . htmlspecialchars($nombre_subgenero) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No se encontraron libros</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>





