<?php
$servername = "154.38.166.102:3306";
$username = "acaro";
$password = "acaro";
$dbname = "g1_sgg";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>