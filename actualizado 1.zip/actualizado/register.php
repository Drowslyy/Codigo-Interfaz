<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión / Registrarse</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="header">
    <div class="menu container">
        <a href="index.html" class="logo">GYM</a>
        <nav class="navbar">
            <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="#">Nosotros</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="login.html">Iniciar Sesión</a></li>   
                <li><a href="register.html">Registrarse</a></li>  
            </ul>
        </nav>
    </div>
</header>

<section class="formulario container">
    <div class="tabs">
        
    
    <form method="post" action="register.html">
    <!-- Formulario de Registrarse -->
    
        <h2>Registrarse</h2>
        <div class="input-container">
            <input type="text" name="nombre" placeholder="Nombre Completo" required>
            <i class="fa-solid fa-user"></i>
        </div>
        <div class="input-container">
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <i class="fa-solid fa-at"></i>
        </div>
        <div class="input-container">
            <input type="password" name="password" placeholder="Contraseña" required>
            <i class="fa-solid fa-lock"></i>
        </div>
        <button type="submit" class="btn">Registrarse</button>
    </form>
    
    </div>
</section>

<script>
    function showForm(formType) {
        document.getElementById('register').style.display = formType === 'register' ? 'block' : 'none';
    }
</script>

</body>
</html>
