<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header class= "header">

        <div class= "menu container">
            <a href="#" class ="logo">GYM</a>
            <input type="checkbox" id= "menu" />
            <label for="menu">
                <img src="ImageGimnasio/menu.png" class= "menu-icon" alt="menu">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="#"> Inicio</a></li>
                    <li><a href="#"> Nosotros</a></li>
                    <li><a href="#"> Servicios</a></li>
                    <li><a href="login.php">Iniciar Sesión</a></li>
                    <li><a href="register.html">Registrarse</a></li>
                </ul>
            </nav>
        </div>

        <div class="header-content container">
            <div class="header-txt">
                <h1>Central Gym</h1>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium earum nostrum, unde eveniet et ipsum, laudantium, fuga quae soluta 
                    minima veniam ullam. Cupiditate veniam nemo esse cumque sequi minima ipsam?
                </p>
                <a href="#" class="btn-1">informacion</a>
            </div>
            <div class="header-img">
                <img src="ImageGimnasio/gym.jpg" alt="">
            </div>


                
            
        </div>
            
    
    
    </header>

    <section class="about container">

        <div class="inicio">
            <img src="ImageGimnasio/inicio.png" alt=""/>
        </div>
        <div class="about-txt">
            <h2>Acerca de Nosotros</h2>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Praesentium earum nostrum, unde eveniet et ipsum, laudantium, fuga quae soluta minima veniam ullam. Cupiditate veniam nemo esse cumque sequi minima ipsam?
            </p>
            <br>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus ea consequuntur, unde exercitationem saepe sequi eaque quod omnis, ad, facilis harum eum temporibus adipisci voluptas odit cupiditate. Ipsa, suscipit nesciunt.

            </p>
        </div>
    </section>

    <main class="servicios">
        <h2>Servicios</h2>
        <div class="servicios-cont container">

            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador Personal</h3>
            </div>
            <div class="servicios-1">
                <i class="fa-sharp fa-solid fa-user"></i><i class="fa-sharp fa-solid fa-dumbbell"></i>
                <h3>Entrenador de Fuerza y Acondicionamiento</h3>

            </div>
            <div class="servicios-1">
                <i class="fa-solid fa-user"></i>
                <h3>Instructor de Yoga o Pilates</h3>
            </div>
        </div>
    </main>

    <section class="formulario container">

        <form method="post" autocomplete="off">
            <h2>Contactanos</h2>


            <div class="input-group">

                <div class="input-container">
                    <input type="text" name="nombre" placeholder="Nombre Completo" required>
                    <i class="fa-solid fa-user"></i>
                </div>
                <div class="input-container">
                    <input type="tel" name="phone" placeholder="9-XXXX-XXXX" required>
                    <i class="fa-solid fa-phone"></i>
                </div>

                <div class="input-container">
                    <input type="text" name="Peso" placeholder="X Kg" required>
                    <i class="fa-solid fa-weight-hanging"></i>
                </div>
                <div class="input-container">
                    <input type="text" name="Altura" placeholder="X.XX Metros" required>
                    <i class="fa-solid fa-ruler-vertical"></i>
                    

                </div>

                <div class="input-container">
                    <input type="email" name="email" placeholder="Correo Electrónico" required>
                    <i class="fa-solid fa-at"></i>
                </div>

                <div class="input-container">
                    <input type="text" name="nombre_entrenador" placeholder="Nombre del entrenador y servicio." required>
                    <i class="fa-solid fa-user"></i>


                <div class="input-container">
                    <textarea type="message" name="Detalles" placeholder="Ingrese metas" required></textarea>
                <div>
                    <input type="submit" name="send" class="btn" onClick="myFunction()">
                </div>

        </form>

    </section>
    <footer class="footer">
        
        <div class="footer-content container">

            <div class="link">
                <a href="#" class="logo"></a>
                

            </div>

            <div class="link">
                <li><a href="#">Inicio</a></li>
                <li><a href="#">Nosotros</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="#">Iniciar Sesión</a></li>
                <li><a href="#">Registrarse</a></li>

            </div>

        </div>

    </footer>


</body>
</html>