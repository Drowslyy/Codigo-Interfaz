<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "libreria";

// Establecer la conexión con la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si el cliente ha iniciado sesión y tiene el rol correcto
if (!isset($_SESSION['user_id'], $_SESSION['role']) || $_SESSION['role'] !== 'usuario') {
    header('Location: login.php');
    exit();
}

// Obtener el ID del cliente y su nombre
$user_id = $_SESSION['user_id'];
$nombre_usuario = "";

// Consulta preparada para obtener el nombre del usuario

$sql_nombre_completo = "SELECT nombre_completo FROM clientes WHERE id = ?";
$stmt_nombre_completo = $conn->prepare($sql_nombre_completo);
$stmt_nombre_completo->bind_param("i", $user_id);
$stmt_nombre_completo->execute();
$stmt_nombre_completo->store_result();
// Verificar si se encontró un usuario con el ID proporcionado

if($stmt_nombre_completo->num_rows > 0){
    $stmt_nombre_completo->bind_result($nombre_usuario);
    $stmt_nombre_completo->fetch();
}else{
    // Si no se encontró un usuario, redirigir a la página de inicio de sesión...
    header('Location: login.php');
    exit();
}

$stmt_nombre_completo->close();
// Obtener el estado de la membresia
$cliente_estado_membresia = $_SESSION['estado_membresia'];
$estado_membresia = "";

// Consulta para obtener si tiene membresia diponible o no disponible
$sql_estado_membresia = "SELECT estado_membresia FROM clientes WHERE id = ?";
$stmt_estado_membresia = $conn->prepare($sql_estado_membresia);
$stmt_estado_membresia->bind_param("i", $cliente_estado_membresia);
$stmt_estado_membresia->execute();
$stmt_estado_membresia->store_result();

//Verificar si se encontro un cliente con la membresia seleccionada en la base de datos
if($stmt_estado_membresia->num_rows > 0){
    $stmt_estado_membresia->bind_result($estado_membresia);
    $stmt_estado_membresia->fetch();
}else {
    // Si no se encontró un cliente con la membresía seleccionada, establecer un mensaje de error
    $_SESSION['mensaje_error'] = 'Su membresía ha vencido. Por favor, renueve su membresía.';
    
    // Redirigir a la página de membresías
    header('Location: membresias.php');
    exit();
}