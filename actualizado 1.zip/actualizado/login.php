<!-- CONEXION AL SERVIDOR -->
<?php
session_start();
$servername = "154.38.166.102:3306";
$username = "acaro";
$password = "acaro";
$dbname = "g1_sgg";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}




?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión / Registrarse</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header class="header">
    <div class="menu container">
        <a href="index.html" class="logo">GYM</a>
        <nav class="navbar">
            <ul>
                <li><a href="index.html">Inicio</a></li>
                <li><a href="#">Nosotros</a></li>
                <li><a href="#">Servicios</a></li>
                <li><a href="login.html">Iniciar Sesión</a></li>
                <li><a href="register.html">Registrarse</a></li>
            </ul>
        </nav>
    </div>
</header>

<section class="formulario container">
    <div class="tabs">
        
        

    
    <!-- Formulario de Iniciar Sesión -->
    
        <h2>Iniciar Sesión</h2>
        <div class="input-container">
            <input type="email" name="email" placeholder="Correo Electrónico" required>
            <i class="fa-solid fa-at"></i>
        </div>
        <div class="input-container">
            <input type="password" name="password" placeholder="Contraseña" required>
            <i class="fa-solid fa-lock"></i>
        </div>
        <button type="submit" class="btn">Iniciar Sesión</button>
    </form>
    </div>

<script>
    function showForm(formType) {
        document.getElementById('login').style.display = formType === 'login' ? 'block' : 'none';
    }
</script>

</body>
</html>
